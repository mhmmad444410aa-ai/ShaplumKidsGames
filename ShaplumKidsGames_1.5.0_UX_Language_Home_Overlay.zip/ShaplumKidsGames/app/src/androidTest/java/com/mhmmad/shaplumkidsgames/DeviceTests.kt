package com.mhmmad.shaplumkidsgames

import android.content.pm.ActivityInfo
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.uiautomator.UiDevice
import com.mhmmad.shaplumkidsgames.data.*
import com.mhmmad.shaplumkidsgames.engine.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class DeviceTests {
    @get:Rule val ui=createAndroidComposeRule<MainActivity>()
    private val vm get()=ViewModelProvider(ui.activity)[GameViewModel::class.java]
    private fun ready() {ui.waitUntil(20000) {vm.state.value.page!=Page.LOADING};ui.runOnIdle {vm.chooseLanguage("en-GB");vm.welcome()};ui.waitForIdle()}
    private fun act(a:Action) {ui.runOnIdle {vm.action(a)}}
    private fun solve(id:Int) {
        ui.runOnIdle {vm.start(id)}
        var limit=0
        while(vm.state.value.saved.session?.complete==false && limit++<1000) {
            val s=vm.state.value.saved.session!!
            val a=if(s.flipped.size==2)Action.HidePair else Engine.hint(s)!!
            act(a)
        }
        assertTrue(vm.state.value.saved.session!!.complete)
    }
    private fun shot(name:String) {
        ui.waitForIdle()
        // Semantics can settle before a software emulator presents the new frame.
        InstrumentationRegistry.getInstrumentation().waitForIdleSync()
        android.os.SystemClock.sleep(1200)
        val device=UiDevice.getInstance(InstrumentationRegistry.getInstrumentation())
        val folder=File(ui.activity.getExternalFilesDir(null),"screenshots").apply {mkdirs()}
        assertTrue(device.takeScreenshot(File(folder,"$name.png")))
    }
    @Test fun allEightGamesRenderAcceptInputAndSave() {
        ready();shot("01_world_en")
        for(mode in Mode.entries) {
            ui.runOnIdle {vm.navigate(Page.MODES)};ui.waitForIdle()
            // A lazy grid does not compose every offscreen island on smaller phones.
            ui.onNode(hasScrollToIndexAction()).performScrollToIndex(mode.ordinal)
            ui.onNodeWithTag("mode_${mode.ordinal}").performClick()
            // Each tile now starts the activity directly instead of showing an extra menu.
            ui.onNodeWithTag("gameplay").assertExists()
            shot("game_${mode.ordinal}_en")
            val before=vm.state.value.saved.session!!
            when(val action=Engine.hint(before)!!) {
                is Action.Place -> {ui.onNodeWithTag("piece_${action.piece}").performClick();ui.onNodeWithTag("target_${action.target}").performClick()}
                is Action.Choose ->ui.onNodeWithTag("option_${action.option}").performClick()
                is Action.Flip ->ui.onNodeWithTag("card_${action.card}").performClick()
                is Action.Move ->ui.onNodeWithTag("cell_${action.cell.x}_${action.cell.y}").performClick()
                else ->error("Unexpected first action")
            }
            assertNotEquals(before,vm.state.value.saved.session)
            ui.onNodeWithTag("pause").performClick();ui.onNodeWithTag("unpause").performClick()
            repeat(3) {solve(mode.ordinal*15+it)}
        }
        ui.runOnIdle {vm.navigate(Page.PROGRESS)};shot("02_progress_en")
        val scores=vm.state.value.saved.scores
        ui.activityRule.scenario.recreate();ui.waitForIdle()
        assertEquals(scores,vm.state.value.saved.scores)
    }
    @Test fun localisationsSettingsParentGateAndRotation() {
        ready()
        for(lang in listOf("en-GB","ar","pt-BR")) {
            ui.runOnIdle {vm.chooseLanguage(lang);vm.navigate(Page.WORLD)}
            ui.onNodeWithTag("play_now").assertExists()
            shot("world_$lang")
            ui.onNodeWithTag("settings").performClick();ui.onNodeWithTag("sound").performClick();ui.onNodeWithTag("motion").performClick()
            ui.onNodeWithTag("language_settings").performClick();ui.onNodeWithTag("lang_$lang").assertExists();ui.onNodeWithTag("language_continue").performClick()
            ui.runOnIdle {vm.start(0)};shot("shapes_$lang")
            ui.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            ui.waitForIdle();ui.runOnIdle {vm.pause(false)};ui.onNodeWithTag("gameplay").assertExists();shot("landscape_$lang")
            ui.activity.requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            ui.waitForIdle();ui.runOnIdle {vm.navigate(Page.WORLD)}
        }
        ui.runOnIdle {vm.chooseLanguage("en-GB")}
        ui.onNodeWithTag("parents").performClick()
        ui.onNodeWithTag("gate_hold").performSemanticsAction(androidx.compose.ui.semantics.SemanticsActions.OnLongClick)
        ui.waitUntil(5000) {ui.onAllNodesWithTag("gate_question").fetchSemanticsNodes().isNotEmpty()}
        val q=ui.onNodeWithTag("gate_question").fetchSemanticsNode().config[androidx.compose.ui.semantics.SemanticsProperties.Text].joinToString {it.text}
        val values=Regex("\\d+").findAll(q).map {it.value.toInt()}.toList()
        ui.onNodeWithTag("gate_answer").performTextInput((values[0]*values[1]+values[2]).toString())
        ui.onNodeWithTag("gate_verify").performClick();ui.onNodeWithTag("about").performClick();shot("03_about_en")
    }
    @Test fun pausePanelUsesSelectedLanguageAndStaysInsideGame() {
        ready()
        val examples=listOf(
            "en-GB" to "Take a little break",
            "ar" to "خذ استراحة صغيرة",
            "pt-BR" to "Hora de uma pausa"
        )
        for((language,heading) in examples) {
            ui.runOnIdle {vm.chooseLanguage(language);vm.start(0)}
            ui.waitForIdle()
            ui.onNodeWithTag("pause").performClick()
            ui.onNodeWithTag("pause_panel").assertExists()
            ui.onNodeWithTag("pause_heading").assertTextEquals(heading)
            ui.onNodeWithTag("unpause").performClick()
            ui.onNodeWithTag("pause_panel").assertDoesNotExist()
            ui.onNodeWithTag("gameplay").assertExists()
        }
    }
    @Test fun saveCodecAndDataStoreRoundTripRecoverFromDamage()= runBlocking {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        val store=ProgressStore(context)
        var session=Engine.start(46)
        session=Engine.reduce(session,Engine.hint(session)!!)
        val saved=SavedGame("ar",true,false,false,mapOf(0 to 3,1 to 2),session)
        assertEquals(saved,ProgressStore.decode(ProgressStore.encode(saved)))
        store.save(saved);assertEquals(saved,store.data.first())
        assertTrue(ProgressStore.decode("{broken").recovered)
        assertTrue(ProgressStore.decode("{\"version\":99}").recovered)
        store.save(SavedGame())
    }
}

package com.mhmmad.shaplumkidsgames.engine

import kotlin.math.abs

data class Session(
    val levelId: Int, val placed: Map<Int, Int> = emptyMap(), val rotations: Map<Int, Int> = emptyMap(),
    val round: Int = 0, val matched: Set<Int> = emptySet(), val flipped: List<Int> = emptyList(),
    val position: Cell = Cell(0, 0), val hasKey: Boolean = false, val trail: Set<Cell> = setOf(Cell(0, 0)),
    val mistakes: Int = 0, val hints: Int = 0, val moves: Int = 0, val complete: Boolean = false,
)
sealed interface Action {
    data class Place(val piece: Int, val target: Int): Action
    data class Rotate(val piece: Int): Action
    data class Choose(val option: Int): Action
    data class Flip(val card: Int): Action
    data object HidePair: Action
    data class Move(val cell: Cell): Action
    data object Hint: Action
}
object Engine {
    fun start(id: Int) = Session(id, position = Levels.get(id).maze?.start ?: Cell(0, 0))
    fun reduce(s: Session, a: Action): Session {
        if (s.complete) return s
        val l = Levels.get(s.levelId)
        return when (a) {
            is Action.Place -> {
                if (a.piece !in l.pieces.indices || a.piece in s.placed) return s
                val p = l.pieces[a.piece].copy(turn = s.rotations[a.piece] ?: l.pieces[a.piece].turn)
                val t = if (l.mode == Mode.ARCHITECT) l.blueprint.getOrNull(a.target)?.piece else l.targets.getOrNull(a.target)
                if (t == null) return s
                val valid = when (l.mode) {
                    Mode.SHAPES -> p.shape == t.shape && a.target !in s.placed.values
                    Mode.SHADOWS -> p.shape == t.shape && (l.difficulty == 0 || p.turn == t.turn) && a.target !in s.placed.values
                    Mode.COLORS -> p.color == t.color && (l.rule == 0 || p.shape == t.shape)
                    Mode.ARCHITECT -> p.shape == t.shape && p.color == t.color && a.target !in s.placed.values &&
                        (l.blueprint[a.target].support == -1 || l.blueprint[a.target].support in s.placed.values)
                    else -> false
                }
                if (valid) {
                    val placed = s.placed + (a.piece to a.target)
                    s.copy(placed = placed, moves = s.moves + 1, complete = placed.size == l.pieces.size)
                } else s.copy(mistakes = s.mistakes + 1, moves = s.moves + 1)
            }
            is Action.Rotate -> if (l.mode == Mode.SHADOWS && a.piece in l.pieces.indices && a.piece !in s.placed)
                s.copy(rotations = s.rotations + (a.piece to ((s.rotations[a.piece] ?: 0) + 1) % 4)) else s
            is Action.Choose -> {
                val correct = when (l.mode) {
                    Mode.PATTERNS -> l.pieces.getOrNull(a.option) == l.targets.getOrNull(s.round)
                    Mode.LOGIC -> a.option in 0..2 && a.option == l.answers.getOrNull(s.round)
                    else -> return s
                }
                if (correct) s.copy(round = s.round + 1, moves = s.moves + 1, complete = s.round + 1 == if (l.mode == Mode.PATTERNS) l.targets.size else l.answers.size)
                else s.copy(mistakes = s.mistakes + 1, moves = s.moves + 1)
            }
            is Action.Flip -> {
                if (l.mode != Mode.MEMORY || a.card !in l.pieces.indices || a.card in s.matched || a.card in s.flipped || s.flipped.size == 2) return s
                val flip = s.flipped + a.card
                if (flip.size == 2 && l.pieces[flip[0]] == l.pieces[flip[1]]) {
                    val matched = s.matched + flip
                    s.copy(matched = matched, flipped = emptyList(), moves = s.moves + 1, complete = matched.size == l.pieces.size)
                } else s.copy(flipped = flip, moves = s.moves + 1, mistakes = s.mistakes + if (flip.size == 2) 1 else 0)
            }
            Action.HidePair -> s.copy(flipped = emptyList())
            is Action.Move -> {
                val m = l.maze ?: return s
                if (a.cell !in m.open || abs(a.cell.x - s.position.x) + abs(a.cell.y - s.position.y) != 1 || (a.cell == m.door && !s.hasKey)) return s
                s.copy(position = a.cell, hasKey = s.hasKey || a.cell == m.key, trail = s.trail + a.cell, moves = s.moves + 1, complete = a.cell == m.end)
            }
            Action.Hint -> s.copy(hints = s.hints + 1)
        }
    }
    fun stars(s: Session): Int = if (!s.complete) 0 else when { s.hints == 0 && s.mistakes <= 2 -> 3; s.hints <= 2 -> 2; else -> 1 }
    fun progress(s: Session): Float {
        val l = Levels.get(s.levelId)
        return when (l.mode) {
            Mode.MAZE -> if (s.complete) 1f else (s.trail.size.toFloat() / (l.maze?.open?.size ?: 1)).coerceAtMost(.95f)
            Mode.MEMORY -> s.matched.size.toFloat() / l.pieces.size
            Mode.PATTERNS -> s.round.toFloat() / l.targets.size
            Mode.LOGIC -> s.round.toFloat() / l.answers.size
            else -> s.placed.size.toFloat() / l.pieces.size
        }
    }
    /** A hint identifies one legal next action; it never completes the action for the child. */
    fun hint(s: Session): Action? {
        val l = Levels.get(s.levelId)
        return when (l.mode) {
            Mode.SHAPES, Mode.COLORS, Mode.SHADOWS, Mode.ARCHITECT -> {
                for (i in l.pieces.indices.filter { it !in s.placed }) {
                    val targets = if (l.mode == Mode.ARCHITECT) l.blueprint.map { it.piece } else l.targets
                    for (j in targets.indices) {
                        val a = Action.Place(i, j)
                        if (reduce(s, a).placed.size > s.placed.size) return a
                        if (l.mode == Mode.SHADOWS && l.pieces[i].shape == targets[j].shape && j !in s.placed.values) return Action.Rotate(i)
                    }
                }
                null
            }
            Mode.PATTERNS -> Action.Choose(l.pieces.indexOf(l.targets[s.round]))
            Mode.LOGIC -> Action.Choose(l.answers[s.round])
            Mode.MEMORY -> {
                val first = s.flipped.firstOrNull()
                val available = l.pieces.indices.filter { it !in s.matched && it !in s.flipped }
                val card = if (first != null) available.firstOrNull { l.pieces[it] == l.pieces[first] } else available.firstOrNull()
                card?.let { Action.Flip(it) }
            }
            Mode.MAZE -> {
                val m = l.maze!!
                val goal = if (!s.hasKey && m.key != null) m.key else m.end
                val open = if (!s.hasKey && m.door != null) m.open - m.door else m.open
                Levels.path(open, s.position, goal).getOrNull(1)?.let { Action.Move(it) }
            }
        }
    }
    fun unlocked(mode: Mode, scores: Map<Int, Int>) = true // All eight games available from launch; levels still advance inside each game.
    fun levelUnlocked(id: Int, scores: Map<Int, Int>) = id % 15 == 0 || scores.containsKey(id - 1)
}

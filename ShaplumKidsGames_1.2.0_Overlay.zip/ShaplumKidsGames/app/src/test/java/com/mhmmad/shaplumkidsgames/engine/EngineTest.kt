package com.mhmmad.shaplumkidsgames.engine

import org.junit.Assert.*
import org.junit.Test

class EngineTest {
    @Test fun all120LevelsHaveLegalSolutions() {
        assertEquals(120,Levels.all.size)
        assertEquals((0..119).toList(),Levels.all.map {it.id})
        Levels.all.forEach { l ->
            var s=Engine.start(l.id);var count=0
            while(!s.complete && count++<1000) {
                if(s.flipped.size==2) s=Engine.reduce(s,Action.HidePair)
                val a=Engine.hint(s) ?: error("No legal next action: ${l.id}, $s")
                val next=Engine.reduce(s,a)
                assertNotEquals("Hint must advance ${l.id}",s,next)
                s=next
            }
            assertTrue("Unsolved level ${l.id}",s.complete)
            assertTrue(Engine.stars(s) in 1..3)
            assertEquals(1f,Engine.progress(s),0.0001f)
        }
    }
    @Test fun everyIslandHas15DistinctLevelsAndThreeTiers() {
        Mode.entries.forEach { mode ->
            val levels=Levels.all.filter {it.mode==mode}
            assertEquals(15,levels.size)
            assertEquals(listOf(5,5,5),levels.groupBy {it.difficulty}.values.map {it.size})
            val signatures=levels.map {l ->listOf(l.pieces,l.targets,l.pattern,l.answers,l.blueprint,l.maze,l.rule).toString()}
            assertEquals("Duplicate content in $mode",15,signatures.distinct().size)
        }
    }
    @Test fun invalidPlacementsDoNotConsumePieces() {
        val l=Levels.get(0);val s=Engine.start(0)
        val wrong=l.targets.indexOfFirst {it.shape!=l.pieces[0].shape}
        val bad=Engine.reduce(s,Action.Place(0,wrong))
        assertTrue(bad.placed.isEmpty());assertEquals(1,bad.mistakes)
        assertEquals(s,Engine.reduce(s,Action.Place(-1,0)))
    }
    @Test fun completedTargetCannotBeReused() {
        var s=Engine.start(0);val a=Engine.hint(s) as Action.Place
        s=Engine.reduce(s,a)
        assertEquals(s,Engine.reduce(s,a))
        val b=Engine.reduce(s,Action.Place((a.piece+1)%Levels.get(0).pieces.size,a.target))
        assertEquals(s.placed,b.placed)
    }
    @Test fun shadowsRequireRotation() {
        val l=Levels.get(3*15+6)
        val target=l.targets.indexOfFirst {it.turn!=0}
        val piece=l.pieces.indexOfFirst {it.shape==l.targets[target].shape}
        var s=Engine.start(l.id)
        assertFalse(Engine.reduce(s,Action.Place(piece,target)).placed.containsKey(piece))
        repeat(l.targets[target].turn) {s=Engine.reduce(s,Action.Rotate(piece))}
        assertTrue(Engine.reduce(s,Action.Place(piece,target)).placed.containsKey(piece))
    }
    @Test fun architectureRequiresSupport() {
        val l=Levels.get(75);val i=l.blueprint.indexOfFirst {it.support>=0};val p=l.pieces.indexOf(l.blueprint[i].piece)
        val s=Engine.reduce(Engine.start(l.id),Action.Place(p,i))
        assertTrue(s.placed.isEmpty())
    }
    @Test fun allMazesKeysReachableBeforeDoors() {
        Levels.all.filter {it.mode==Mode.MAZE}.forEach {l ->
            val m=l.maze!!;assertTrue(Levels.path(m.open,m.start,m.end).isNotEmpty())
            if(m.key!=null && m.door!=null) assertTrue(Levels.path(m.open-m.door,m.start,m.key).isNotEmpty())
        }
    }
    @Test fun mazeDoesNotTeleportOrPassLockedDoor() {
        val l=Levels.get(66);val s=Engine.start(l.id);val m=l.maze!!
        assertEquals(s,Engine.reduce(s,Action.Move(m.end)))
        if(m.door!=null) {
            val before=Levels.path(m.open,m.start,m.door).dropLast(1).last()
            val near=s.copy(position=before)
            assertEquals(near,Engine.reduce(near,Action.Move(m.door)))
        }
    }
    @Test fun memoryIgnoresRepeatedOrThirdCard() {
        val l=Levels.get(90);var s=Engine.start(l.id)
        s=Engine.reduce(s,Action.Flip(0));assertEquals(s,Engine.reduce(s,Action.Flip(0)))
        val wrong=l.pieces.indices.first {l.pieces[it]!=l.pieces[0]}
        s=Engine.reduce(s,Action.Flip(wrong))
        assertEquals(2,s.flipped.size)
        assertEquals(s,Engine.reduce(s,Action.Flip(l.pieces.lastIndex)))
        assertTrue(Engine.reduce(s,Action.HidePair).flipped.isEmpty())
    }
    @Test fun hintDoesNotSolveAutomaticallyAndStarsHaveFloor() {
        val s=Engine.start(0);val hint=Engine.reduce(s,Action.Hint)
        assertEquals(s.placed,hint.placed);assertFalse(hint.complete)
        assertEquals(1,Engine.stars(s.copy(complete=true,hints=99,mistakes=99)))
    }
    @Test fun allGamesAvailableAndLevelsStillTrackProgress() {
        Mode.entries.forEach { assertTrue(Engine.unlocked(it,emptyMap())) }
        val scores=mapOf(0 to 1,1 to 2,2 to 3)
        assertTrue(Engine.unlocked(Mode.COLORS,scores));assertTrue(Engine.levelUnlocked(3,scores));assertFalse(Engine.levelUnlocked(4,scores))
    }
    @Test fun reducersDoNotChangeFinishedSessions() {
        val s=Engine.start(0).copy(complete=true)
        assertEquals(s,Engine.reduce(s,Action.Hint));assertEquals(s,Engine.reduce(s,Action.Place(0,0)))
    }
}

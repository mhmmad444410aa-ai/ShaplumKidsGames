> **Build status (v1.1):** The enhanced pastel-UI source in this archive has not been compiled into an APK in this working environment. The separately provided signed APK is the original v1.0.0. Do not distribute the v1.1 source ZIP as if it were a signed release. The keystore is intentionally excluded from this repository.

# Shaplum Kids Games

An original, offline Android game for children aged 4–8. Eight geometric islands contain 120 playable levels. Default language: English (UK), with complete Arabic and Brazilian Portuguese resources.

`com.mhmmad.shaplumkidsgames` · 1.1.0 (source update) · version code 2 · min SDK 23 · target SDK 36

## Play

Match shapes, sort colours, extend patterns, rotate shapes into shadows, navigate keyed mazes, build supported structures, find memory pairs, and solve five kinds of visual logic puzzles. Every island has 15 levels in three difficulty tiers. Complete three levels to unlock the next island. Earn one to three stars without time limits, purchases, or advertising. Hints highlight a legal move without playing it automatically.

Drag a piece into its destination, or tap the piece and then its destination. Game-board coordinates stay consistent in Arabic; menus use RTL. The app supports portrait and landscape with a square board and a side panel in wide layouts.

## Build

Install JDK 17 and Android SDK platform 36 / build-tools 35.0.0. Create an untracked `local.properties` containing `sdk.dir=/your/android/sdk` or set `ANDROID_HOME`.

```bash
chmod +x gradlew
./gradlew testDebugUnitTest lintRelease assembleDebug assembleRelease
./gradlew connectedDebugAndroidTest
python3 tools/verify_resources.py
```

Versions are pinned: Gradle 8.11.1, Android Gradle Plugin 8.10.1, Kotlin and Compose compiler 2.1.21, Compose BOM 2025.05.01. Android dependencies are fetched from Google Maven and Maven Central. No external source modules, local AARs, Google Play services, or Huawei services are needed to play. The Gradle Wrapper JAR is included. JDK 21 JRE-only installations cannot compile this project: use a full JDK 17.

`assembleRelease` produces an **unsigned** release when signing variables are absent; it does not substitute a debug key. Debug builds use the `.debug` application ID suffix. A signed release requires all four values below plus a keystore file path.

```text
RELEASE_KEYSTORE_PATH=/private/path/shaplum-release.jks
RELEASE_STORE_PASSWORD=...
RELEASE_KEY_ALIAS=shaplum
RELEASE_KEY_PASSWORD=...
PRIVACY_POLICY_URL=https://your-real-domain/your-published-policy
SUPPORT_EMAIL=your-real-support-address
```

Use your permanent keystore for every update. Never generate a second key for an existing published package. Keep at least two private backups outside the public repository. See `docs/SIGNING_AR.md`.

## GitHub Actions

`.github/workflows/android.yml` runs resource checks, JVM tests, release lint, unsigned release/debug builds, and connected tests on an Android 30 emulator. The signed-release job runs only on explicit workflow dispatch, after both verification jobs pass. It requires a `release` environment, four repository signing secrets and the real privacy URL and support email in repository variables. It uploads an APK artifact and removes the temporary keystore. This workflow is supplied as source; a remote GitHub run is verified only when an actual run URL/result exists.

## Architecture

* `engine/Levels.kt`: content-versioned deterministic configurations, maze generator, 120 level definitions.
* `engine/Engine.kt`: pure immutable state reducer; validates moves, support relationships, matching, doors/keys, hints, stars and unlocks.
* `data/ProgressStore.kt`: one versioned local DataStore record for progress, language, preferences and the active session. Conflated writes persist the most recent state; I/O errors expose a retry action. Invalid saved records recover to a fresh game.
* `GameViewModel.kt`: StateFlow-based navigation and game state, save orchestration and lifecycle pause.
* `ui/`: Compose layouts, native vector Canvas artwork, drag/tap boards, accessible labels, menu motion and reward animation.
* `ads/`: a fail-closed interface with child-directed policy. No ad SDK, ad requests or ad toggle in v1.

The visual assets are original geometric drawings, with no people, animals, stock-game art, or music. The two audio effects are original filtered noise. Fonts are provided by the Android system.

## Verification

JVM tests solve every level through legal reducer actions, check content uniqueness, progression, invalid inputs, rotation, memory state, maze reachability and construction support. Device tests exercise actual UI input for all eight games, locale switching, screen rotation, parent gate, settings, save encoding/DataStore, and recreation. Screenshots are captured directly from the running app by device tests. See the delivered QA report for **actual executed results**, rather than treating test source as proof of a pass.

## Child privacy

No account, network permission, analytics, ads, location, camera, microphone, contacts, billing, or identifiers. Saves are local, Android backup is disabled, and local progress can be reset in the parent zone. The parent zone requires a hold plus a random arithmetic question; it is a deterrent rather than an identity/age verification service. External links are restricted to About within that zone, and the zone closes when the app backgrounds. Privacy text is available offline in About. The public privacy-policy link appears only when a real HTTPS URL is supplied at build time.

## Publication blockers

Before store submission, publish and verify the policy with the publisher's real name and support contact, configure `PRIVACY_POLICY_URL` and `SUPPORT_EMAIL`, rebuild using the same permanent key, and complete the store's age/privacy questionnaires. Confirm the name in target-region trademark registers and AppGallery itself. Initial web search is not trademark clearance. Test on a physical Huawei device, including TalkBack, low-end performance and large accessibility fonts. Mainland China game publication has additional qualifications; do not select it without checking the relevant requirements.

Acceptance is not guaranteed. Educational categories are competitive and AppGallery's originality/saturation review remains discretionary. Do not publish a copy with another package/name, use misleading metadata, or activate advertising after review without a new compliance review and accurate privacy declarations.

from pathlib import Path
import re,xml.etree.ElementTree as ET,sys
root=Path(__file__).resolve().parents[1]
folders=['values','values-en-rGB','values-ar','values-pt-rBR']
baseline=None
for folder in folders:
    path=root/'app/src/main/res'/folder/'strings.xml'
    values={e.attrib['name']:e.text or '' for e in ET.parse(path).getroot()}
    assert all(values.values()),f'Empty translation: {folder}'
    if baseline is None:baseline=values
    assert values.keys()==baseline.keys(),f'Missing keys: {folder}'
    for key,text in values.items():
        assert sorted(re.findall(r'%\d+\$[sd]',text))==sorted(re.findall(r'%\d+\$[sd]',baseline[key])),f'Format mismatch: {folder}/{key}'
    assert len(values['app_name'])<=30
for file in root.rglob('*'):
    if not file.is_file() or any(p in file.parts for p in ['build','.gradle','.git','.kotlin']):continue
    assert file.suffix not in ['.jks','.keystore','.p12'],f'Signing secret in public source: {file}'
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
assert not manifest.findall('uses-permission'),'Unexpected permission'
assert (root/'gradle/wrapper/gradle-wrapper.jar').stat().st_size>40000
print(f'PASS: {len(baseline)} strings × {len(folders)} resource sets, names <=30 characters, no permissions or signing files')

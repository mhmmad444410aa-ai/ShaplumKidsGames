"""Workspace helper; ordinary environments can run ./gradlew directly."""
import os,sys,subprocess,urllib.parse
from pathlib import Path
root=Path(__file__).resolve().parents[1]
env=os.environ.copy()
proxy=urllib.parse.urlparse(env.get('HTTPS_PROXY',''))
if proxy.hostname:
    env['GRADLE_OPTS']=f'-Dhttp.proxyHost={proxy.hostname} -Dhttp.proxyPort={proxy.port} -Dhttps.proxyHost={proxy.hostname} -Dhttps.proxyPort={proxy.port} -Dhttp.nonProxyHosts=localhost|127.*'
sys.exit(subprocess.call([str(root/'gradlew'),*sys.argv[1:]],cwd=root,env=env))

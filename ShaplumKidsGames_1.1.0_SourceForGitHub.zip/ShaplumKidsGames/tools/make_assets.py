from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math, wave, struct, random, shutil
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'store/assets';OUT.mkdir(parents=True,exist_ok=True)
COLORS=['#7B5CFA','#11CDAA','#FFC857','#FF668B','#57B9FA']
def icon(size=512):
    n=1024
    im=Image.new('RGB',(n,n));px=im.load()
    for y in range(n):
        for x in range(n):
            glow=max(0,1-math.hypot((x-500)/850,(y-360)/850))
            px[x,y]=(int(32+glow*34),int(21+glow*19),int(64+glow*46))
    d=ImageDraw.Draw(im)
    d.ellipse((120,820,900,920),fill='#291A49')
    d.polygon([(150,615),(510,520),(870,615),(740,810),(510,930),(280,810)],fill='#59408F')
    d.polygon([(150,615),(510,690),(510,930),(280,810)],fill='#42306F')
    d.ellipse((145,515,875,710),fill='#0A9C8B')
    d.ellipse((145,500,875,680),fill='#11CDAA')
    d.ellipse((180,515,840,650),outline='#63E3C9',width=5)
    d.rounded_rectangle((340,365,590,585),radius=25,fill='#5D3AD0')
    d.polygon([(340,365),(375,342),(625,342),(590,365)],fill='#A88BFF')
    d.polygon([(590,365),(625,342),(625,562),(590,585)],fill='#4D32A9')
    d.polygon([(320,370),(467,160),(615,370)],fill='#FF668B')
    d.polygon([(467,160),(495,147),(640,345),(615,370)],fill='#C9446C')
    d.rounded_rectangle((425,446,510,585),radius=40,fill='#201540')
    d.rounded_rectangle((630,450,747,574),radius=15,fill='#FFC857')
    d.polygon([(630,450),(650,438),(767,438),(747,450)],fill='#FFE6A0')
    d.polygon([(747,450),(767,438),(767,560),(747,574)],fill='#C89538')
    d.rounded_rectangle((237,527,310,600),radius=16,fill='#7B5CFA')
    d.ellipse((238,266,325,353),fill='#57B9FA')
    d.polygon([(770,230),(822,290),(770,350),(718,290)],fill='#FFC857')
    for x,y,r in [(180,460,10),(850,390,7),(680,130,8),(375,100,7),(150,165,5),(830,760,7)]: d.ellipse((x-r,y-r,x+r,y+r),fill='#FAF7FF')
    return im.resize((size,size),Image.Resampling.LANCZOS)
im=icon();im.save(OUT/'Shaplum_Icon_512.png')
for density,size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    folder=ROOT/f'app/src/main/res/mipmap-{density}';folder.mkdir(parents=True,exist_ok=True)
    im.resize((size,size),Image.Resampling.LANCZOS).save(folder/'ic_launcher.png')
f=Image.new('RGB',(1024,500),'#201540');d=ImageDraw.Draw(f)
for i in range(45):
    r=random.Random(i+12);x=r.randrange(1024);y=r.randrange(500);d.ellipse((x,y,x+2,y+2),fill='#68568F')
art=icon(460);f.paste(art,(550,20))
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
d.text((55,95),'Shaplum',font=ImageFont.truetype(bold,68),fill='#FAF7FF')
d.text((58,185),'Kids Games',font=ImageFont.truetype(bold,34),fill='#FFC857')
d.text((58,255),'Small shapes.',font=ImageFont.truetype(regular,27),fill='#D7CBF5')
d.text((58,294),'Big discoveries.',font=ImageFont.truetype(regular,27),fill='#D7CBF5')
d.rounded_rectangle((55,367,492,428),radius=22,fill='#11CDAA')
d.text((78,383),'8 games · 120 offline levels',font=ImageFont.truetype(bold,23),fill='#201540')
f.save(OUT/'Shaplum_Feature_1024x500.png')
raw=ROOT/'app/src/main/res/raw';raw.mkdir(parents=True,exist_ok=True)
for name,seconds,seed in [('soft_pop',.085,31),('sparkle_air',.42,47)]:
    r=random.Random(seed);samples=[];prev=0
    for i in range(int(22050*seconds)):
        t=i/22050;env=math.sin(math.pi*t/seconds)**2*math.exp(-3*t/seconds)
        noise=r.uniform(-1,1);prev=prev*.72+noise*.28
        # A short filtered air/wood effect, without melody or musical notes.
        samples.append(int(max(-1,min(1,prev*env*.7))*32767))
    with wave.open(str(raw/f'{name}.wav'),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(22050);w.writeframes(struct.pack('<'+'h'*len(samples),*samples))
print('Original icon, feature graphic and 2 non-musical effects generated')

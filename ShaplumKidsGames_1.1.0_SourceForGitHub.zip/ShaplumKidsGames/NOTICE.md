# Attribution

The game logic, geometric illustrations, icons, promotional artwork, and filtered-noise sound effects in this repository were authored for Shaplum. No third-party game assets, character drawings or music are included.

The project uses upstream development/runtime components under their own licences, including AndroidX and Jetpack Compose (Apache 2.0), Kotlin and Kotlin Coroutines (Apache 2.0), and the Gradle Wrapper (Apache 2.0). Dependency coordinates and pinned versions appear in the Gradle files. Android system fonts are used at runtime and are not redistributed as font files in this project. The local JDK, Android SDK, emulator/system images and downloaded Maven/Gradle caches are development tools and are not included in the source delivery.

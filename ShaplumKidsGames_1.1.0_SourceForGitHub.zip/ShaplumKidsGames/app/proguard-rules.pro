# No reflection-based domain models or third-party SDKs.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

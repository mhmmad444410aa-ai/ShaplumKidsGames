package com.mhmmad.shaplumkidsgames

import android.content.res.Configuration
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mhmmad.shaplumkidsgames.ui.ShaplumApp
import java.util.Locale

class MainActivity: ComponentActivity() {
    private val model: GameViewModel by viewModels()
    private var sounds: SoundPool? = null
    private var clickSound = 0
    private var successSound = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(0xFFFDE7F8.toInt()),
        )
        sounds = SoundPool.Builder().setMaxStreams(3).setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build().also {
            clickSound=it.load(this,R.raw.soft_pop,1); successSound=it.load(this,R.raw.sparkle_air,1)
        }
        setContent {
            val state by model.state.collectAsStateWithLifecycle()
            val locale = remember(state.saved.language) { Locale.forLanguageTag(state.saved.language) }
            val context = remember(locale) { createConfigurationContext(Configuration(resources.configuration).apply { setLocale(locale);setLayoutDirection(locale) }) }
            CompositionLocalProvider(LocalContext provides context, LocalConfiguration provides context.resources.configuration, LocalLayoutDirection provides if(locale.language=="ar") LayoutDirection.Rtl else LayoutDirection.Ltr) {
                ShaplumApp(state,model) { success ->
                    if(state.saved.sound) sounds?.play(if(success)successSound else clickSound,.35f,.35f,1,0,1f)
                }
            }
        }
    }
    override fun onStop() { model.background();super.onStop() }
    override fun onDestroy() { sounds?.release();sounds=null;super.onDestroy() }
}

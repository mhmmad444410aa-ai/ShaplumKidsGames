package com.mhmmad.shaplumkidsgames.ads

/** Deliberate, fail-closed extension point. No advertising SDK is packaged in v1. */
data class ChildAdRequestPolicy(
    val childProtection: Boolean = true,
    val underAgeOfConsent: Boolean = true,
    val nonPersonalizedOnly: Boolean = true,
    val allowLocation: Boolean = false,
    val maximumContentRating: String = "W",
)
interface ChildSafeAds {
    val policy: ChildAdRequestPolicy
    fun canRequest(): Boolean
    fun release()
}
object NoAds: ChildSafeAds {
    override val policy = ChildAdRequestPolicy()
    override fun canRequest() = false
    override fun release() = Unit
}

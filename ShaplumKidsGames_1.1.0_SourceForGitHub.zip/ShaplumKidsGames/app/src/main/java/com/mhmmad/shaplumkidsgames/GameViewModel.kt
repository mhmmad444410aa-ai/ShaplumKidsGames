package com.mhmmad.shaplumkidsgames

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mhmmad.shaplumkidsgames.data.*
import com.mhmmad.shaplumkidsgames.engine.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Page { LOADING, LANGUAGE, WELCOME, WORLD, MODES, MAP, PLAY, SUCCESS, PROGRESS, SETTINGS, GATE, PARENTS, ABOUT }
data class UiState(val saved: SavedGame = SavedGame(), val page: Page = Page.LOADING, val mode: Mode = Mode.SHAPES, val paused: Boolean = false, val saveFailed: Boolean = false)
class GameViewModel(app: Application): AndroidViewModel(app) {
    private val repository = ProgressStore(app)
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    private val writes = Channel<SavedGame>(Channel.CONFLATED)
    init {
        viewModelScope.launch {
            val saved = repository.data.first()
            kotlinx.coroutines.delay(1000)
            _state.value = UiState(saved,if (saved.welcomed) Page.WORLD else Page.LANGUAGE)
        }
        viewModelScope.launch {
            for (next in writes) try { repository.save(next); _state.update { it.copy(saveFailed=false) } }
            catch (_: java.io.IOException) { _state.update { it.copy(saveFailed=true) } }
        }
    }
    private fun change(block: (SavedGame) -> SavedGame) {
        val s = block(_state.value.saved); _state.update { it.copy(saved=s) }; writes.trySend(s)
    }
    fun navigate(page: Page) { _state.update { it.copy(page=page,paused=false) } }
    fun chooseLanguage(language: String) { change { it.copy(language=language) } }
    fun welcome() { change { it.copy(welcomed=true) }; navigate(Page.WORLD) }
    fun mode(mode: Mode) { if (Engine.unlocked(mode,state.value.saved.scores)) _state.update { it.copy(mode=mode,page=Page.MAP) } }
    fun start(id: Int) {
        if (!Engine.unlocked(Levels.get(id).mode,state.value.saved.scores) || !Engine.levelUnlocked(id,state.value.saved.scores)) return
        change { it.copy(session=Engine.start(id)) }; _state.update { it.copy(mode=Levels.get(id).mode,page=Page.PLAY,paused=false) }
    }
    fun resume() { if (state.value.saved.session != null) navigate(if (state.value.saved.session!!.complete) Page.SUCCESS else Page.PLAY) }
    fun action(action: Action) {
        if (state.value.page != Page.PLAY || state.value.paused) return
        val old = state.value.saved.session ?: return
        val next = Engine.reduce(old,action)
        if (old == next) return
        change { s -> s.copy(session=next,scores=if (next.complete) s.scores + (next.levelId to maxOf(s.scores[next.levelId] ?: 0,Engine.stars(next))) else s.scores) }
        if (next.complete) navigate(Page.SUCCESS)
    }
    fun pause(value: Boolean) { _state.update { it.copy(paused=value) } }
    fun next() { val id=state.value.saved.session?.levelId ?: return; if (id % 15 < 14) start(id+1) else navigate(Page.WORLD) }
    fun toggleSound() { change { it.copy(sound=!it.sound) } }
    fun toggleMotion() { change { it.copy(motion=!it.motion) } }
    fun reset() { change { it.copy(scores=emptyMap(),session=null) }; navigate(Page.PARENTS) }
    fun retrySave() { writes.trySend(state.value.saved) }
    fun background() {
        if (state.value.page in listOf(Page.PARENTS,Page.ABOUT,Page.GATE)) navigate(Page.WORLD)
        if (state.value.page == Page.PLAY) pause(true)
    }
    fun back() {
        val page = state.value.page
        when (page) {
            Page.PLAY -> pause(!state.value.paused)
            Page.MAP -> navigate(Page.WORLD)
            Page.ABOUT -> navigate(Page.PARENTS)
            Page.LANGUAGE -> if (state.value.saved.welcomed) navigate(Page.SETTINGS) else navigate(Page.WELCOME)
            Page.WELCOME -> navigate(Page.LANGUAGE)
            Page.LOADING,Page.WORLD -> Unit
            else -> navigate(Page.WORLD)
        }
    }
}

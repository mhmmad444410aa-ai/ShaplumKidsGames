package com.mhmmad.shaplumkidsgames.engine

import kotlin.random.Random

enum class Mode { SHAPES, COLORS, PATTERNS, SHADOWS, MAZE, ARCHITECT, MEMORY, LOGIC }
enum class Shape { CIRCLE, SQUARE, TRIANGLE, DIAMOND, HEXAGON, STAR, ARCH, CHEVRON }
data class Piece(val shape: Shape, val color: Int, val turn: Int = 0)
data class Cell(val x: Int, val y: Int)
data class Blueprint(val piece: Piece, val x: Int, val y: Int, val support: Int = -1)
data class Maze(val width: Int, val height: Int, val open: Set<Cell>, val start: Cell, val end: Cell, val key: Cell?, val door: Cell?)
data class Level(
    val id: Int, val mode: Mode, val number: Int, val pieces: List<Piece>,
    val targets: List<Piece> = emptyList(), val pattern: List<Piece> = emptyList(),
    val answers: List<Int> = emptyList(), val blueprint: List<Blueprint> = emptyList(),
    val maze: Maze? = null, val rule: Int = 0,
) {
    val difficulty get() = (number - 1) / 5
    val rounds get() = answers.size
}

/** Versioned, deterministic content: fifteen authored rule/size combinations per island. */
object Levels {
    const val CONTENT_VERSION = 1
    val all: List<Level> by lazy { Mode.entries.flatMap { m -> (1..15).map { make(m, it) } } }
    fun get(id: Int): Level = all[id.coerceIn(0, 119)]
    private fun make(mode: Mode, n: Int): Level {
        val r = Random(84109 + mode.ordinal * 2003 + n * 137)
        val tier = (n - 1) / 5
        val id = mode.ordinal * 15 + n - 1
        fun p(i: Int) = Piece(Shape.entries[(i + n - 1) % Shape.entries.size], (i * 2 + n) % 5)
        return when (mode) {
            Mode.SHAPES -> {
                val targets = List(3 + tier * 2) { p(it).copy(turn = 0) }
                Level(id, mode, n, targets.shuffled(r), targets, rule = (n - 1) % 5)
            }
            Mode.COLORS -> {
                // Late levels require both the colour and the container's shape.
                val count = 2 + tier
                val targets = List(count) { Piece(Shape.entries[(it + n) % 8], (it + n) % 5) }
                val pieces = List(4 + tier * 2) { i ->
                    val t = targets[i % count]
                    if (tier < 2) t.copy(shape = Shape.entries[(i + n * 2) % 8]) else t
                }
                Level(id, mode, n, pieces.shuffled(r), targets, rule = if (tier == 2) 1 else 0)
            }
            Mode.PATTERNS -> {
                val period = when ((n - 1) % 5) { 0 -> listOf(0, 1); 1 -> listOf(0, 0, 1); 2 -> listOf(0, 1, 2); 3 -> listOf(0, 1, 1); else -> listOf(0, 1, 2, 1) }
                val items = List(4) { p(it) }
                val length = 4 + tier
                val pattern = List(length + 2 + tier) { items[period[it % period.size]] }
                Level(id, mode, n, items.shuffled(r), pattern = pattern.take(length),
                    targets = pattern.drop(length), rule = period.size)
            }
            Mode.SHADOWS -> {
                val targets = List(3 + tier * 2) { i ->
                    // Rotation is only used for asymmetric shapes, so orientation has one meaning.
                    val sh = if (tier > 0) listOf(Shape.TRIANGLE, Shape.ARCH, Shape.CHEVRON)[i % 3] else Shape.entries[(i + n) % 8]
                    Piece(sh, (i + n) % 5, if (tier > 0) (i + n) % 4 else 0)
                }
                val pieces = targets.map { it.copy(turn = 0) }.shuffled(r)
                Level(id, mode, n, pieces, targets, rule = tier)
            }
            Mode.MAZE -> Level(id, mode, n, listOf(p(0)), maze = createMaze(5 + tier * 2, r, tier > 0), rule = n % 5)
            Mode.ARCHITECT -> {
                val kind = (n - 1) % 5
                val slots = mutableListOf<Blueprint>()
                fun add(x: Int, y: Int, shape: Shape, color: Int, support: Int = -1) { slots += Blueprint(Piece(shape, color), x, y, support) }
                when (kind) {
                    0 -> { // House with a roof, then extra storeys.
                        add(1, 3, Shape.SQUARE, n % 5); add(3, 3, Shape.SQUARE, n % 5)
                        add(2, 2, Shape.SQUARE, (n + 1) % 5, 0); add(2, 1, Shape.TRIANGLE, (n + 2) % 5, 2)
                    }
                    1 -> { // Bridge, piers before deck.
                        add(0, 3, Shape.SQUARE, 2); add(4, 3, Shape.SQUARE, 2)
                        add(0, 2, Shape.SQUARE, 1, 0); add(4, 2, Shape.SQUARE, 1, 1)
                        add(1, 1, Shape.SQUARE, 3, 2); add(2, 1, Shape.SQUARE, 3, 4); add(3, 1, Shape.SQUARE, 3, 3)
                    }
                    2 -> { // Tower.
                        for (y in 4 downTo 1) add(2, y, Shape.SQUARE, (y + n) % 5, if (y == 4) -1 else slots.lastIndex)
                        add(2, 0, Shape.TRIANGLE, 2, slots.lastIndex)
                    }
                    3 -> { // Castle.
                        add(0, 3, Shape.SQUARE, 0); add(2, 3, Shape.ARCH, 1); add(4, 3, Shape.SQUARE, 0)
                        add(0, 2, Shape.SQUARE, 2, 0); add(4, 2, Shape.SQUARE, 2, 2)
                        add(0, 1, Shape.TRIANGLE, 3, 3); add(4, 1, Shape.TRIANGLE, 3, 4)
                    }
                    else -> { // Stepped monument.
                        add(0, 4, Shape.SQUARE, 2); add(1, 4, Shape.SQUARE, 2); add(3, 4, Shape.SQUARE, 2); add(4, 4, Shape.SQUARE, 2)
                        add(1, 3, Shape.SQUARE, 0, 1); add(3, 3, Shape.SQUARE, 0, 2); add(2, 2, Shape.DIAMOND, 3, 4)
                    }
                }
                repeat(tier) { j -> add(2, -j, Shape.STAR, (j + n) % 5, slots.lastIndex) }
                Level(id, mode, n, slots.map { it.piece }.shuffled(r), blueprint = slots, rule = kind)
            }
            Mode.MEMORY -> {
                val pairs = 3 + tier * 2 + if (n % 5 == 0) 1 else 0
                val base = List(pairs) { p(it) }
                Level(id, mode, n, (base + base).shuffled(r), rule = n % 5)
            }
            Mode.LOGIC -> {
                // Different reasoning rules: odd shape, odd colour, size of set,
                // intersection of shape + colour, and completing a transformation.
                val rule = (n - 1) % 5
                val rounds = 3 + tier
                val options = mutableListOf<Piece>(); val examples = mutableListOf<Piece>(); val answers = mutableListOf<Int>()
                repeat(rounds) { round ->
                    val base = p(round)
                    val other = p(round + 1)
                    val local = when (rule) {
                        0 -> listOf(base, base.copy(color = (base.color + 1) % 5), other)
                        1 -> listOf(base, base.copy(shape = other.shape), other.copy(color = (base.color + 1) % 5))
                        2 -> listOf(base, other, p(round + 2))
                        3 -> listOf(base, base.copy(color = other.color), base.copy(shape = other.shape))
                        else -> listOf(base, other.copy(color = base.color), base.copy(color = other.color))
                    }
                    val correct = when (rule) { 0, 1 -> 2; 2 -> (round + n) % 3; 3 -> 0; else -> 2 }
                    val order = listOf(0, 1, 2).shuffled(r)
                    options += order.map { local[it] }; answers += order.indexOf(correct)
                    examples += when (rule) { 2 -> local[correct]; 4 -> base; else -> base }
                    if (rule == 4) examples += other
                }
                Level(id, mode, n, options, pattern = examples, answers = answers, rule = rule)
            }
        }
    }

    private fun createMaze(size: Int, r: Random, locked: Boolean): Maze {
        val open = mutableSetOf(Cell(0, 0)); val visited = mutableSetOf(Cell(0, 0))
        fun carve(c: Cell) {
            listOf(Cell(2, 0), Cell(-2, 0), Cell(0, 2), Cell(0, -2)).shuffled(r).forEach { d ->
                val n = Cell(c.x + d.x, c.y + d.y)
                if (n.x in 0 until size && n.y in 0 until size && visited.add(n)) {
                    open += Cell(c.x + d.x / 2, c.y + d.y / 2); open += n; carve(n)
                }
            }
        }
        carve(Cell(0, 0))
        val end = Cell(size - 1, size - 1)
        val path = path(open, Cell(0, 0), end)
        val door = if (locked && path.size > 5) path[path.size * 2 / 3] else null
        val key = if (door != null) path[path.size / 3] else null
        return Maze(size, size, open, Cell(0, 0), end, key, door)
    }
    fun path(open: Set<Cell>, start: Cell, end: Cell): List<Cell> {
        val queue = ArrayDeque<Cell>(); queue += start
        val prev = mutableMapOf<Cell, Cell?>(start to null)
        while (queue.isNotEmpty()) {
            val c = queue.removeFirst()
            if (c == end) break
            listOf(Cell(c.x + 1, c.y), Cell(c.x - 1, c.y), Cell(c.x, c.y + 1), Cell(c.x, c.y - 1)).forEach {
                if (it in open && !prev.containsKey(it)) { prev[it] = c; queue += it }
            }
        }
        if (end !in prev) return emptyList()
        val out = mutableListOf<Cell>(); var c: Cell? = end
        while (c != null) { out += c; c = prev[c] }
        return out.reversed()
    }
}

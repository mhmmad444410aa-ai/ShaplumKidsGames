package com.mhmmad.shaplumkidsgames.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import com.mhmmad.shaplumkidsgames.engine.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

private val Context.gameStore by preferencesDataStore(
    name = "shaplum_progress_v1",
    corruptionHandler = ReplaceFileCorruptionHandler { androidx.datastore.preferences.core.emptyPreferences() },
)
data class SavedGame(
    val language: String = "en-GB", val welcomed: Boolean = false, val sound: Boolean = true,
    val motion: Boolean = true, val scores: Map<Int, Int> = emptyMap(), val session: Session? = null,
    val recovered: Boolean = false,
)
class ProgressStore(context: Context) {
    private val dataStore = context.applicationContext.gameStore
    private val key = stringPreferencesKey("state_v1")
    val data = dataStore.data.catch { e -> if (e is IOException) emit(androidx.datastore.preferences.core.emptyPreferences()) else throw e }
        .map { prefs -> decode(prefs[key]) }
    suspend fun save(state: SavedGame) { dataStore.edit { it[key] = encode(state) } }
    companion object {
        fun encode(s: SavedGame): String = JSONObject().apply {
            put("version", 1); put("language", s.language); put("welcomed", s.welcomed)
            put("sound", s.sound); put("motion", s.motion)
            put("scores", JSONObject().apply { s.scores.forEach { (k,v) -> put(k.toString(), v) } })
            s.session?.let { g -> put("session", JSONObject().apply {
                put("id", g.levelId); put("placed", JSONObject().apply { g.placed.forEach { (k,v) -> put(k.toString(),v) } })
                put("rotations", JSONObject().apply { g.rotations.forEach { (k,v) -> put(k.toString(),v) } })
                put("round",g.round); put("matched",JSONArray(g.matched.toList())); put("flipped",JSONArray(g.flipped))
                put("x",g.position.x); put("y",g.position.y); put("key",g.hasKey)
                put("trail",JSONArray().apply { g.trail.forEach { put(JSONArray(listOf(it.x,it.y))) } })
                put("mistakes",g.mistakes); put("hints",g.hints); put("moves",g.moves); put("complete",g.complete)
            }) }
        }.toString()
        fun decode(raw: String?): SavedGame {
            if (raw == null) return SavedGame()
            return try {
                val o = JSONObject(raw)
                require(o.optInt("version",1) == 1)
                fun map(j: JSONObject?) = buildMap<Int,Int> { j?.keys()?.forEach { k -> k.toIntOrNull()?.let { put(it,j.optInt(k)) } } }
                fun ints(a: JSONArray?) = List(a?.length() ?: 0) { a!!.getInt(it) }
                val scores = map(o.optJSONObject("scores")).filter { it.key in 0..119 && it.value in 1..3 }
                val session = o.optJSONObject("session")?.let { g ->
                    val id = g.getInt("id"); require(id in 0..119)
                    val l = Levels.get(id)
                    val placed = map(g.optJSONObject("placed")); val rotations = map(g.optJSONObject("rotations"))
                    require(placed.keys.all { it in l.pieces.indices })
                    val maxTargets = if (l.mode == Mode.ARCHITECT) l.blueprint.size else l.targets.size
                    require(placed.values.all { it in 0 until maxTargets })
                    val round = g.optInt("round"); require(round in 0..maxOf(l.targets.size,l.answers.size))
                    val matched = ints(g.optJSONArray("matched")).toSet(); require(matched.all { it in l.pieces.indices })
                    val flipped = ints(g.optJSONArray("flipped")); require(flipped.size <= 2 && flipped.all { it in l.pieces.indices })
                    val pos = Cell(g.optInt("x"),g.optInt("y")); require(l.maze == null || pos in l.maze.open)
                    Session(id,placed,rotations,round,matched,flipped,pos,g.optBoolean("key"),
                        g.optJSONArray("trail")?.let { a -> (0 until a.length()).map { Cell(a.getJSONArray(it).getInt(0),a.getJSONArray(it).getInt(1)) }.toSet() } ?: setOf(pos),
                        g.optInt("mistakes").coerceAtLeast(0),g.optInt("hints").coerceAtLeast(0),g.optInt("moves").coerceAtLeast(0),g.optBoolean("complete"))
                }
                SavedGame(o.optString("language","en-GB").takeIf { it in listOf("en-GB","ar","pt-BR") } ?: "en-GB",
                    o.optBoolean("welcomed"),o.optBoolean("sound",true),o.optBoolean("motion",true),scores,session)
            } catch (_: Exception) { SavedGame(recovered = true) }
        }
    }
}

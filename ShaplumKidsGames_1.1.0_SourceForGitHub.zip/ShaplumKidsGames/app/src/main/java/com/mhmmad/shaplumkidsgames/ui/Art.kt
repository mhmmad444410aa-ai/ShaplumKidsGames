package com.mhmmad.shaplumkidsgames.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import com.mhmmad.shaplumkidsgames.engine.*
import com.mhmmad.shaplumkidsgames.engine.Shape
import kotlin.math.*

val Ink = Color(0xFF253456)
val Purple = Color(0xFF934CEB)
val Mint = Color(0xFF28D9B7)
val Gold = Color(0xFFFFC948)
val Coral = Color(0xFFFF7295)
val Paper = Color(0xFFFFFFFF)
val Muted = Color(0xFF63728D)
val Palette = listOf(Purple, Mint, Gold, Coral, Color(0xFF55BAF6))

fun DrawScope.shape(piece: Piece, center: Offset, radius: Float, silhouette: Boolean = false, faded: Boolean = false, glow: Boolean = false) {
    val color = if (silhouette) Color(0xFF856D9C) else Palette[piece.color % Palette.size]
    val alpha = if (faded) .25f else 1f
    val path = Path().apply {
        when (piece.shape) {
            Shape.CIRCLE -> addOval(Rect(center - Offset(radius,radius), Size(radius*2,radius*2)))
            Shape.SQUARE -> addRoundRect(RoundRect(Rect(center - Offset(radius*.88f,radius*.88f),Size(radius*1.76f,radius*1.76f)),CornerRadius(radius*.22f)))
            Shape.ARCH -> {
                fillType = PathFillType.EvenOdd
                moveTo(center.x-radius*.85f,center.y+radius*.85f);lineTo(center.x-radius*.85f,center.y-radius*.1f)
                cubicTo(center.x-radius*.85f,center.y-radius*1.25f,center.x+radius*.85f,center.y-radius*1.25f,center.x+radius*.85f,center.y-radius*.1f)
                lineTo(center.x+radius*.85f,center.y+radius*.85f);close()
                addRoundRect(RoundRect(Rect(center.x-radius*.35f,center.y-radius*.05f,center.x+radius*.35f,center.y+radius*1.1f),CornerRadius(radius*.3f)))
            }
            Shape.CHEVRON -> {
                listOf(Offset(-.9f,-.8f),Offset(0f,-.25f),Offset(.9f,-.8f),Offset(.9f,.2f),Offset(0f,.9f),Offset(-.9f,.2f)).forEachIndexed { i,v ->
                    if (i==0) moveTo(center.x+v.x*radius,center.y+v.y*radius) else lineTo(center.x+v.x*radius,center.y+v.y*radius)
                };close()
            }
            else -> {
                val count = when(piece.shape) { Shape.TRIANGLE->3;Shape.DIAMOND->4;Shape.HEXAGON->6;else->10 }
                repeat(count) { i ->
                    val angle = -PI/2 + 2*PI*i/count
                    val r = if (piece.shape==Shape.STAR && i%2==1) radius*.48f else radius
                    val x = center.x+cos(angle).toFloat()*r;val y = center.y+sin(angle).toFloat()*r
                    if(i==0) moveTo(x,y) else lineTo(x,y)
                };close()
            }
        }
    }
    rotate(piece.turn*90f,center) {
        if(glow) drawCircle(Gold.copy(alpha=.17f),radius*1.4f,center)
        if(!silhouette && !faded) translate(top=radius*.13f) { drawPath(path,color.copy(red=color.red*.58f,green=color.green*.58f,blue=color.blue*.58f)) }
        drawPath(path,if(silhouette) SolidColor(color) else Brush.linearGradient(listOf(Color.White.copy(alpha=.20f).compositeOver(color),color),center-Offset(radius,radius),center+Offset(radius,radius)),alpha=alpha)
        drawPath(path,if(glow) Gold else Color.White.copy(alpha=if(silhouette) .15f else .35f),style=Stroke(if(glow) radius*.075f else radius*.035f))
        if(!silhouette && !faded) drawCircle(Color.White.copy(alpha=.35f),radius*.08f,center-Offset(radius*.27f,radius*.3f))
    }
}

@Composable
fun ShapeArt(piece: Piece, modifier: Modifier = Modifier, silhouette: Boolean = false, faded: Boolean = false, glow: Boolean = false) {
    Canvas(modifier) { shape(piece,center,min(size.width,size.height)*.36f,silhouette,faded,glow) }
}

fun DrawScope.islandArt(index: Int, t: Float = 0f, unlocked: Boolean = true) {
    val sc = min(size.width/400f,size.height/280f)
    val dx=(size.width-400f*sc)/2;val dy=(size.height-280f*sc)/2
    translate(dx,dy) { scale(sc,sc,Offset.Zero) {
        val lift=sin(t*PI*2).toFloat()*4
        translate(top=lift) {
            drawOval(Color.Black.copy(alpha=.16f),Offset(68f,248f),Size(264f,18f))
            val rock=Path().apply { moveTo(46f,167f);lineTo(195f,130f);lineTo(356f,169f);lineTo(307f,220f);lineTo(205f,260f);lineTo(102f,222f);close() }
            drawPath(rock,Brush.verticalGradient(listOf(Color(0xFFDEBF9B),Color(0xFF936C65)),140f,260f))
            drawPath(Path().apply {moveTo(46f,167f);lineTo(205f,196f);lineTo(205f,260f);lineTo(102f,222f);close()},Color(0xFFAE7E69))
            drawPath(Path().apply {moveTo(205f,196f);lineTo(356f,169f);lineTo(307f,220f);lineTo(205f,260f);close()},Color(0xFFB88C70))
            drawOval(Color(0xFF40985D),Offset(44f,134f),Size(314f,65f))
            val top=if(unlocked) Color(0xFF80D46B) else Color(0xFFA5A9A6)
            drawOval(Brush.verticalGradient(listOf(top.copy(alpha=.92f),top.copy(alpha=.55f))),Offset(44f,123f),Size(314f,65f))
            drawOval(Color.White.copy(alpha=.16f),Offset(59f,130f),Size(284f,45f),style=Stroke(2f))
            fun block(x:Float,y:Float,w:Float,h:Float,c:Color) {
                drawRoundRect(c,Offset(x,y),Size(w,h),CornerRadius(7f))
                drawPath(Path().apply {moveTo(x,y);lineTo(x+14,y-9);lineTo(x+w+14,y-9);lineTo(x+w,y);close()},c.copy(red=(c.red+.15f).coerceAtMost(1f),green=(c.green+.15f).coerceAtMost(1f),blue=(c.blue+.15f).coerceAtMost(1f)))
                drawPath(Path().apply {moveTo(x+w,y);lineTo(x+w+14,y-9);lineTo(x+w+14,y+h-9);lineTo(x+w,y+h);close()},c.copy(red=c.red*.7f,green=c.green*.7f,blue=c.blue*.7f))
                drawRoundRect(Color.White.copy(alpha=.25f),Offset(x+8,y+8),Size(w*.24f,h*.18f),CornerRadius(2f))
            }
            when(index%4) {
                0 -> { block(149f,88f,73f,66f,Palette[index%5]);block(220f,114f,44f,39f,Gold);shape(Piece(Shape.TRIANGLE,3),Offset(185f,65f),48f);block(105f,130f,33f,29f,Mint) }
                1 -> { block(106f,113f,46f,48f,Purple);block(250f,110f,39f,50f,Coral);block(146f,112f,111f,20f,Gold);shape(Piece(Shape.ARCH,1),Offset(204f,91f),38f) }
                2 -> { block(167f,66f,65f,98f,Purple);block(145f,120f,26f,43f,Mint);block(237f,111f,27f,50f,Coral);shape(Piece(Shape.DIAMOND,2),Offset(201f,39f),31f) }
                else -> { block(115f,111f,43f,52f,Coral);block(240f,111f,43f,52f,Purple);block(156f,131f,84f,31f,Gold);shape(Piece(Shape.TRIANGLE,1),Offset(136f,91f),31f);shape(Piece(Shape.TRIANGLE,2),Offset(260f,91f),31f) }
            }
            repeat(5) { i -> shape(Piece(if(i%2==0) Shape.HEXAGON else Shape.DIAMOND,(i+index)%5),Offset(81f+i*57f,164f+(i%2)*4),6f) }
            shape(Piece(Shape.DIAMOND,(index+2)%5),Offset(54f,81f+cos(t*6f)*9),13f)
            shape(Piece(Shape.SQUARE,(index+3)%5,1),Offset(336f,101f-sin(t*6f)*7),12f)
            drawCircle(Gold.copy(alpha=.2f),11f,Offset(306f,37f));drawCircle(Gold,3f,Offset(306f,37f))
        }
    } }
}
@Composable
fun IslandArt(index: Int, modifier: Modifier = Modifier, motion: Boolean = true, unlocked: Boolean = true) {
    val transition=rememberInfiniteTransition(label="island")
    val t by transition.animateFloat(0f,1f,infiniteRepeatable(tween(5000,easing=LinearEasing)),label="float")
    Canvas(modifier) { islandArt(index,if(motion)t else 0f,unlocked) }
}
enum class Symbol { PLAY,BACK,HOME,SETTINGS,PAUSE,STAR,LOCK,LANGUAGE,TROPHY,HINT,ROTATE,CHECK,SOUND,CLOSE }
@Composable
fun SymbolArt(symbol: Symbol, modifier: Modifier = Modifier, color: Color = Paper) {
    Canvas(modifier) {
        val s=min(size.width,size.height)/32f
        translate((size.width-32*s)/2,(size.height-32*s)/2) { scale(s,s,Offset.Zero) {
            fun line(a:Offset,b:Offset) = drawLine(color,a,b,2.5f,StrokeCap.Round)
            when(symbol) {
                Symbol.PLAY -> drawPath(Path().apply {moveTo(11f,6f);lineTo(27f,16f);lineTo(11f,26f);close()},color)
                Symbol.PAUSE -> {drawRoundRect(color,Offset(8f,7f),Size(6f,18f),CornerRadius(2f));drawRoundRect(color,Offset(19f,7f),Size(6f,18f),CornerRadius(2f))}
                Symbol.STAR -> shape(Piece(Shape.STAR,2),Offset(16f,16f),13f)
                Symbol.BACK -> {line(Offset(23f,16f),Offset(8f,16f));line(Offset(8f,16f),Offset(15f,9f));line(Offset(8f,16f),Offset(15f,23f))}
                Symbol.LOCK -> {drawRoundRect(color,Offset(7f,14f),Size(18f,14f),CornerRadius(4f));drawArc(color,180f,180f,false,Offset(10f,4f),Size(12f,20f),style=Stroke(3f));drawCircle(Ink,2f,Offset(16f,21f))}
                Symbol.HOME -> {line(Offset(4f,15f),Offset(16f,5f));line(Offset(16f,5f),Offset(28f,15f));drawRoundRect(color,Offset(8f,14f),Size(16f,14f),CornerRadius(2f));drawRect(Ink,Offset(14f,20f),Size(5f,8f))}
                Symbol.CHECK -> {line(Offset(6f,17f),Offset(13f,24f));line(Offset(13f,24f),Offset(27f,8f))}
                Symbol.CLOSE -> {line(Offset(8f,8f),Offset(24f,24f));line(Offset(8f,24f),Offset(24f,8f))}
                Symbol.HINT -> {drawCircle(color,9f,Offset(16f,12f),style=Stroke(2.5f));line(Offset(11f,23f),Offset(21f,23f));line(Offset(13f,28f),Offset(19f,28f))}
                Symbol.ROTATE -> {drawArc(color,15f,290f,false,Offset(6f,6f),Size(20f,20f),style=Stroke(3f));line(Offset(27f,5f),Offset(27f,14f));line(Offset(20f,14f),Offset(27f,14f))}
                Symbol.SETTINGS -> {repeat(8) { rotate(it*45f,Offset(16f,16f)) {drawRoundRect(color,Offset(13f,2f),Size(6f,8f),CornerRadius(2f))} };drawCircle(color,10f,Offset(16f,16f));drawCircle(Ink,4.5f,Offset(16f,16f))}
                Symbol.LANGUAGE -> {drawCircle(color,12f,Offset(16f,16f),style=Stroke(2f));drawOval(color,Offset(10f,4f),Size(12f,24f),style=Stroke(2f));line(Offset(4f,16f),Offset(28f,16f))}
                Symbol.TROPHY -> {drawRoundRect(color,Offset(9f,5f),Size(14f,17f),CornerRadius(6f));drawArc(color,0f,180f,false,Offset(3f,5f),Size(26f,17f),style=Stroke(2f));line(Offset(16f,20f),Offset(16f,28f));line(Offset(10f,28f),Offset(22f,28f))}
                Symbol.SOUND -> {drawPath(Path().apply {moveTo(4f,12f);lineTo(11f,12f);lineTo(18f,5f);lineTo(18f,27f);lineTo(11f,20f);lineTo(4f,20f);close()},color);drawArc(color,-60f,120f,false,Offset(13f,7f),Size(16f,18f),style=Stroke(2.5f))}
            }
        } }
    }
}

package com.mhmmad.shaplumkidsgames.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.mhmmad.shaplumkidsgames.*
import com.mhmmad.shaplumkidsgames.R
import com.mhmmad.shaplumkidsgames.engine.*
import com.mhmmad.shaplumkidsgames.engine.Shape
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import java.text.NumberFormat
import java.util.Locale
import kotlin.random.Random

val ModeNames = listOf(R.string.shape_match,R.string.color_sorting,R.string.pattern_builder,R.string.shadow_puzzle,R.string.shape_maze,R.string.little_architect,R.string.memory_tiles,R.string.logic_lab)
val IslandNames = listOf(R.string.shape_island,R.string.color_island,R.string.pattern_island,R.string.shadow_island,R.string.maze_island,R.string.architect_island,R.string.memory_island,R.string.logic_island)
val DifficultyNames = listOf(R.string.easy,R.string.medium,R.string.challenge)
val ShapeNames = listOf(R.string.circle,R.string.square,R.string.triangle,R.string.diamond,R.string.hexagon,R.string.star,R.string.arch,R.string.chevron)
val ColorNames = listOf(R.string.violet,R.string.turquoise,R.string.gold,R.string.coral,R.string.blue)
@Suppress("DEPRECATION")
@Composable fun number(n:Int): String { val config=LocalConfiguration.current;val locale=if(android.os.Build.VERSION.SDK_INT>=24)config.locales[0] else config.locale; return remember(n,locale) { NumberFormat.getIntegerInstance(locale).format(n) } }

@Composable
fun ShaplumApp(state:UiState,vm:GameViewModel,sound:(Boolean)->Unit) {
    val colours=lightColorScheme(primary=Purple,secondary=Mint,background=Color(0xFFECFBFF),surface=Color.White,onPrimary=Color.White,onSurface=Ink,onBackground=Ink)
    MaterialTheme(colorScheme=colours,typography=Typography(bodyLarge=Typography().bodyLarge.copy(fontSize=17.sp),titleLarge=Typography().titleLarge.copy(fontWeight=FontWeight.Bold))) {
        CompositionLocalProvider(LocalContentColor provides Ink) {
        BackHandler(state.page!=Page.WORLD) { vm.back() }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFBDF5FF),Color(0xFFFFF9E7),Color(0xFFFDE7F8))))) {
            StarSky(Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                if(state.saveFailed) Row(Modifier.fillMaxWidth().background(Coral).padding(8.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(stringResource(R.string.save_failed),Modifier.weight(1f),color=Ink)
                    TextButton(onClick=vm::retrySave) {Text(stringResource(R.string.retry),color=Ink)}
                }
                AnimatedContent(state.page,transitionSpec={fadeIn(tween(180)) togetherWith fadeOut(tween(100))},label="page",modifier=Modifier.weight(1f)) { page ->
                    when(page) {
                        Page.LOADING -> Splash(state.saved.motion)
                        Page.LANGUAGE -> Languages(state,vm)
                        Page.WELCOME -> Welcome(state,vm)
                        Page.WORLD -> World(state,vm)
                        Page.MODES -> Modes(state,vm)
                        Page.MAP -> LevelMap(state,vm)
                        Page.PLAY -> Gameplay(state,vm,sound)
                        Page.SUCCESS -> Success(state,vm,sound)
                        Page.PROGRESS -> Progress(state,vm)
                        Page.SETTINGS -> Settings(state,vm)
                        Page.GATE -> ParentGate(vm)
                        Page.PARENTS -> Parents(state,vm)
                        Page.ABOUT -> About(vm)
                    }
                }
            }
        }
        }
    }
}
@Composable fun StarSky(modifier:Modifier) { Canvas(modifier) {
    // Sky, drifting clouds and petals: decorative and never cover touch targets.
    val cloud=Color.White.copy(alpha=.80f)
    listOf(Offset(size.width*.13f,size.height*.10f),Offset(size.width*.82f,size.height*.17f),Offset(size.width*.22f,size.height*.70f)).forEachIndexed { index,p ->
        val r=size.width*(if(index==1).075f else .09f)
        drawOval(cloud,p-Offset(r*1.55f,r*.22f),androidx.compose.ui.geometry.Size(r*3.1f,r*1.12f))
        drawCircle(cloud,r*.75f,p+Offset(-r*.45f,-r*.24f))
        drawCircle(cloud,r*.95f,p+Offset(r*.32f,-r*.36f))
    }
    val stars=listOf(Offset(.12f,.32f),Offset(.91f,.42f),Offset(.08f,.85f),Offset(.80f,.78f),Offset(.48f,.09f))
    stars.forEachIndexed {i,p ->
        val c=if(i%2==0)Color(0xFFFFC445) else Color(0xFFEF73B1)
        val center=Offset(p.x*size.width,p.y*size.height)
        drawCircle(c.copy(alpha=.35f),size.width*.018f,center)
        drawCircle(c,size.width*.007f,center)
    }
} }

@Composable fun ToyHero(modifier:Modifier=Modifier) {
    Image(painter=painterResource(R.drawable.toy_hero),contentDescription=null,
        modifier=modifier.clip(RoundedCornerShape(30.dp)),contentScale=ContentScale.Crop)
}
@Composable fun ModePicture(index:Int, modifier:Modifier=Modifier) {
    val id=when(index) {
        0 -> R.drawable.toy_mode_0
        1 -> R.drawable.toy_mode_1
        2 -> R.drawable.toy_mode_2
        3 -> R.drawable.toy_mode_3
        4 -> R.drawable.toy_mode_4
        5 -> R.drawable.toy_mode_5
        6 -> R.drawable.toy_mode_6
        else -> R.drawable.toy_mode_7
    }
    Image(painter=painterResource(id),contentDescription=null,
        modifier=modifier.clip(RoundedCornerShape(20.dp)),contentScale=ContentScale.Crop)
}

@Composable fun ActionButton(text:String,onClick:()->Unit,modifier:Modifier=Modifier,symbol:Symbol?=null,color:Color=Mint,tag:String="") {
    val labelColor=if(color==Mint || color==Gold) Ink else Color.White
    Button(onClick=onClick,
        modifier=modifier.defaultMinSize(minHeight=58.dp).shadow(7.dp,RoundedCornerShape(22.dp)).testTag(tag),
        shape=RoundedCornerShape(22.dp),
        colors=ButtonDefaults.buttonColors(containerColor=color,contentColor=labelColor),
        contentPadding=PaddingValues(horizontal=22.dp,vertical=15.dp),
        elevation=ButtonDefaults.buttonElevation(defaultElevation=2.dp,pressedElevation=0.dp)) {
        if(symbol!=null) {SymbolArt(symbol,Modifier.size(23.dp),labelColor);Spacer(Modifier.width(10.dp))}
        Text(text,fontWeight=FontWeight.ExtraBold,fontSize=17.sp,textAlign=TextAlign.Center)
    }
}
@Composable fun IconControl(symbol:Symbol,label:String,onClick:()->Unit,tag:String="") {
    val rtl=LocalLayoutDirection.current==LayoutDirection.Rtl
    FilledTonalIconButton(onClick,Modifier.size(52.dp).testTag(tag).semantics { contentDescription=label },shape=RoundedCornerShape(17.dp),colors=IconButtonDefaults.filledTonalIconButtonColors(containerColor=Color.White.copy(alpha=.95f))) { SymbolArt(symbol,Modifier.size(25.dp).graphicsLayer {scaleX=if(symbol==Symbol.BACK && rtl)-1f else 1f},Purple) }
}
@Composable fun Header(title:String,back:()->Unit,action:(@Composable ()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        IconControl(Symbol.BACK,stringResource(R.string.back),back,"back")
        Text(title,Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold)
        action?.invoke()
    }
}
@Composable fun SurfacePanel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Column(modifier.shadow(7.dp,RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha=.96f)).border(2.dp,Color(0xFFE6D9FD),RoundedCornerShape(28.dp)).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
}
@Composable fun Splash(motion:Boolean) { Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
    ToyHero(Modifier.fillMaxWidth(.88f).height(270.dp));Text(stringResource(R.string.brand),fontSize=48.sp,fontWeight=FontWeight.Black);Text(stringResource(R.string.tagline),color=Muted);Spacer(Modifier.height(24.dp));CircularProgressIndicator(color=Mint,modifier=Modifier.size(28.dp))
} }
@Composable fun Languages(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(15.dp)) {
    ToyHero(Modifier.height(175.dp).fillMaxWidth())
    Text(stringResource(R.string.choose_language),fontSize=28.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
    listOf("en-GB" to R.string.english,"ar" to R.string.arabic,"pt-BR" to R.string.portuguese).forEach { (code,label) ->
        ActionButton(stringResource(label),{vm.chooseLanguage(code)},Modifier.fillMaxWidth(),if(s.saved.language==code) Symbol.CHECK else Symbol.LANGUAGE,if(s.saved.language==code) Mint else Purple,"lang_$code")
    }
    Spacer(Modifier.height(10.dp));ActionButton(stringResource(R.string.continue_label),{vm.navigate(if(s.saved.welcomed)Page.SETTINGS else Page.WELCOME)},Modifier.fillMaxWidth(),Symbol.PLAY,Gold,"language_continue")
} }
@Composable fun Welcome(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(18.dp)) {
    ToyHero(Modifier.fillMaxWidth().height(220.dp))
    Text(stringResource(R.string.welcome_title),fontSize=30.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
    Text(stringResource(R.string.welcome_body),color=Muted,fontSize=18.sp,textAlign=TextAlign.Center)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {repeat(3) {ShapeArt(Piece(Shape.entries[it],it+1),Modifier.size(62.dp))}}
    Text(stringResource(R.string.welcome_drag),textAlign=TextAlign.Center)
    ActionButton(stringResource(R.string.play),vm::welcome,Modifier.fillMaxWidth(),Symbol.PLAY,Mint,"welcome_play")
} }
@Composable fun World(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize()) {
    Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {Text(stringResource(R.string.brand),fontSize=32.sp,fontWeight=FontWeight.Black);Text(stringResource(R.string.tagline),color=Muted,fontSize=12.sp)}
        IconControl(Symbol.SETTINGS,stringResource(R.string.settings),{vm.navigate(Page.SETTINGS)},"settings")
    }
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.world_title),fontWeight=FontWeight.Bold,fontSize=27.sp)
        Text(stringResource(R.string.world_subtitle),color=Muted)
        if(s.saved.recovered) Text(stringResource(R.string.recovered),color=Gold)
        Box(Modifier.fillMaxWidth().height(245.dp).shadow(10.dp,RoundedCornerShape(30.dp)).clip(RoundedCornerShape(30.dp)).background(Color.White)) {
            ToyHero(Modifier.fillMaxSize())
            Text(stringResource(R.string.offline_badge),
                Modifier.align(Alignment.BottomCenter).padding(bottom=12.dp).background(Color.White.copy(alpha=.95f),RoundedCornerShape(24.dp)).padding(horizontal=18.dp,vertical=10.dp),
                color=Ink,fontSize=13.sp,fontWeight=FontWeight.ExtraBold)
        }
        if(s.saved.session!=null) ActionButton(stringResource(R.string.resume),vm::resume,Modifier.fillMaxWidth(),Symbol.PLAY,Mint,"resume")
        ActionButton(stringResource(R.string.islands),{vm.navigate(Page.MODES)},Modifier.fillMaxWidth(),Symbol.PLAY,if(s.saved.session==null)Mint else Purple,"all_games")
        Row(verticalAlignment=Alignment.CenterVertically) {SymbolArt(Symbol.STAR,Modifier.size(28.dp));Spacer(Modifier.width(8.dp));Text(stringResource(R.string.stars_total,number(s.saved.scores.values.sum())),fontWeight=FontWeight.ExtraBold,color=Ink);Spacer(Modifier.weight(1f));Text("${number(s.saved.scores.size)} / ${number(120)}",color=Muted)}
        TextButton(onClick={vm.navigate(Page.PROGRESS)},modifier=Modifier.fillMaxWidth().testTag("progress")) {Text(stringResource(R.string.progress),color=Purple)}
        Spacer(Modifier.height(8.dp))
    }
    TextButton(onClick={vm.navigate(Page.GATE)},modifier=Modifier.fillMaxWidth().heightIn(min=48.dp).testTag("parents")) {SymbolArt(Symbol.LOCK,Modifier.size(16.dp),Muted);Spacer(Modifier.width(8.dp));Text(stringResource(R.string.parents),color=Muted,fontSize=13.sp)}
} }
@Composable fun Modes(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize()) {
    Header(stringResource(R.string.islands),{vm.navigate(Page.WORLD)})
    var lockedMessage by remember {mutableStateOf(false)}
    if(lockedMessage) Text(stringResource(R.string.unlock_island),Modifier.padding(horizontal=24.dp,vertical=8.dp),color=Gold)
    LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        items(Mode.entries) { m ->
            val open=Engine.unlocked(m,s.saved.scores)
            val tileColor=Palette[m.ordinal%Palette.size]
            Column(Modifier.shadow(7.dp,RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp))
                .background(if(open) Color.White else Color(0xFFF0EAF4))
                .border(2.dp,if(open)tileColor.copy(alpha=.60f) else Color(0xFFE5DAF1),RoundedCornerShape(26.dp))
                .clickable {if(open) vm.mode(m) else lockedMessage=true}.testTag("mode_${m.ordinal}").padding(9.dp),
                horizontalAlignment=Alignment.CenterHorizontally) {
                Box(Modifier.fillMaxWidth().height(132.dp).clip(RoundedCornerShape(20.dp))) {
                    ModePicture(m.ordinal,Modifier.fillMaxSize().alpha(if(open)1f else .38f))
                    if(!open) Box(Modifier.align(Alignment.Center).background(Color.White.copy(alpha=.87f),RoundedCornerShape(18.dp)).padding(10.dp)) {
                        SymbolArt(Symbol.LOCK,Modifier.size(29.dp),Purple)
                    }
                }
                Spacer(Modifier.height(9.dp))
                Text(stringResource(ModeNames[m.ordinal]),color=Ink,fontWeight=FontWeight.ExtraBold,textAlign=TextAlign.Center,fontSize=16.sp,minLines=2,lineHeight=18.sp)
                Text(stringResource(IslandNames[m.ordinal]),color=Muted,textAlign=TextAlign.Center,fontSize=12.sp,maxLines=2)
                Row(Modifier.padding(top=7.dp,bottom=3.dp),verticalAlignment=Alignment.CenterVertically) {
                    SymbolArt(if(open)Symbol.STAR else Symbol.LOCK,Modifier.size(17.dp),Purple)
                    Spacer(Modifier.width(5.dp))
                    Text(if(open) "${number(s.saved.scores.filterKeys {it/15==m.ordinal}.values.sum())} / ${number(45)}" else stringResource(R.string.locked),color=Ink,fontSize=12.sp,fontWeight=FontWeight.Bold)
                }
            }
        }
    }
} }
@Composable fun LevelMap(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize()) {
    Header(stringResource(ModeNames[s.mode.ordinal]),{vm.navigate(Page.MODES)})
    LazyVerticalGrid(GridCells.Fixed(3),Modifier.weight(1f),contentPadding=PaddingValues(20.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item(span={GridItemSpan(3)}) {Column(horizontalAlignment=Alignment.CenterHorizontally) {ModePicture(s.mode.ordinal,Modifier.fillMaxWidth().height(155.dp));Text(stringResource(IslandNames[s.mode.ordinal]),fontSize=24.sp,fontWeight=FontWeight.Bold);Text(stringResource(R.string.levels),color=Muted)}}
        items(15) { n -> val id=s.mode.ordinal*15+n;val open=Engine.levelUnlocked(id,s.saved.scores);val score=s.saved.scores[id] ?: 0
            Column(Modifier.aspectRatio(.83f).shadow(4.dp,RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(if(open)Color.White else Color(0xFFEDE8F3)).border(2.dp,if(open)Palette[(s.mode.ordinal+n/5)%5].copy(alpha=.65f) else Color(0xFFDCD4E6),RoundedCornerShape(24.dp)).clickable(enabled=open) {vm.start(id)}.testTag("level_$n"),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                if(open) Text(number(n+1),fontSize=30.sp,fontWeight=FontWeight.Black) else SymbolArt(Symbol.LOCK,Modifier.size(27.dp),Muted.copy(alpha=.5f))
                Row {repeat(3) {SymbolArt(Symbol.STAR,Modifier.size(18.dp).alpha(if(it<score)1f else .15f))}}
                Text(stringResource(DifficultyNames[n/5]),color=Muted,fontSize=11.sp,textAlign=TextAlign.Center,modifier=Modifier.padding(top=5.dp))
            }
        }
    }
} }
@Composable fun Success(s:UiState,vm:GameViewModel,sound:(Boolean)->Unit) {
    val game=s.saved.session ?: return
    LaunchedEffect(game.levelId) {sound(true)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(16.dp)) {
        ModePicture(Levels.get(game.levelId).mode.ordinal,Modifier.fillMaxWidth().height(210.dp))
        Text(stringResource(R.string.success_title),fontSize=30.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center,modifier=Modifier.testTag("success"))
        Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {repeat(3) { i ->
            var shown by remember(game.levelId) {mutableStateOf(!s.saved.motion)}
            LaunchedEffect(game.levelId) {delay((i*160).toLong());shown=true}
            val scale by animateFloatAsState(if(shown)1f else .1f,spring(dampingRatio=.45f),label="star")
            SymbolArt(Symbol.STAR,Modifier.size(65.dp).scale(scale).alpha(if(i<Engine.stars(game))1f else .15f))
        }}
        Text(stringResource(R.string.success_body),textAlign=TextAlign.Center,color=Muted)
        if(game.levelId%15==2 && game.levelId/15<7) Text(stringResource(R.string.island_unlocked),color=Gold,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
        ActionButton(stringResource(R.string.next),vm::next,Modifier.fillMaxWidth(),Symbol.PLAY,Mint,"next")
        ActionButton(stringResource(R.string.replay),{vm.start(game.levelId)},Modifier.fillMaxWidth(),Symbol.ROTATE,Purple,"replay")
        TextButton(onClick={vm.navigate(Page.WORLD)}) {Text(stringResource(R.string.home),color=Purple)}
    }
}
@Composable fun Progress(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize()) {
    Header(stringResource(R.string.progress),{vm.navigate(Page.WORLD)})
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Text(stringResource(R.string.stars_total,number(s.saved.scores.values.sum())),fontSize=28.sp,fontWeight=FontWeight.Bold)
        Text(stringResource(R.string.levels_total,number(s.saved.scores.size)),color=Muted)
        SurfacePanel(Modifier.fillMaxWidth()) {Text(stringResource(R.string.reward_garden),fontSize=20.sp,fontWeight=FontWeight.Bold);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {repeat(5) { i -> ShapeArt(Piece(Shape.entries[(i+3)%8],i),Modifier.size(48.dp).alpha(if(s.saved.scores.size>=listOf(1,10,30,60,120)[i])1f else .15f))}}}
        val titles=listOf(R.string.achievement_first,R.string.achievement_ten,R.string.achievement_fifty,R.string.achievement_all)
        val bodies=listOf(R.string.achievement_first_body,R.string.achievement_ten_body,R.string.achievement_fifty_body,R.string.achievement_all_body)
        listOf(1,10,50,120).forEachIndexed { i,goal -> SurfacePanel(Modifier.fillMaxWidth()) {Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(16.dp)) {
            SymbolArt(if(s.saved.scores.size>=goal)Symbol.TROPHY else Symbol.LOCK,Modifier.size(40.dp),if(s.saved.scores.size>=goal)Gold else Muted)
            Column {Text(stringResource(titles[i]),fontWeight=FontWeight.Bold,fontSize=19.sp);Text(stringResource(bodies[i]),color=Muted,fontSize=14.sp)}
        }} }
    }
} }
@Composable fun Settings(s:UiState,vm:GameViewModel) { Column(Modifier.fillMaxSize()) {
    Header(stringResource(R.string.settings),{vm.navigate(Page.WORLD)})
    Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
        SurfacePanel(Modifier.fillMaxWidth()) {
            SettingToggle(stringResource(R.string.sound),s.saved.sound,vm::toggleSound,"sound")
            SettingToggle(stringResource(R.string.motion),s.saved.motion,vm::toggleMotion,"motion")
        }
        ActionButton(stringResource(R.string.language),{vm.navigate(Page.LANGUAGE)},Modifier.fillMaxWidth(),Symbol.LANGUAGE,Purple,"language_settings")
        ActionButton(stringResource(R.string.parents),{vm.navigate(Page.GATE)},Modifier.fillMaxWidth(),Symbol.LOCK,Purple,"parent_settings")
        ModePicture(5,Modifier.fillMaxWidth().height(200.dp))
    }
} }
@Composable fun SettingToggle(title:String,value:Boolean,change:()->Unit,tag:String) {Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
    Text(title,Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=18.sp)
    Switch(checked=value,onCheckedChange={change()},modifier=Modifier.testTag(tag),colors=SwitchDefaults.colors(checkedThumbColor=Ink,checkedTrackColor=Mint))
} }
@Composable fun ParentGate(vm:GameViewModel) {
    var held by remember {mutableStateOf(false)};var holding by remember {mutableStateOf(false)}
    var answer by remember {mutableStateOf("")};var error by remember {mutableStateOf(false)}
    val a=remember {Random.nextInt(12,24)};val b=remember {Random.nextInt(6,10)};val c=remember {Random.nextInt(11,30)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally) {
        Header(stringResource(R.string.gate_title),{vm.navigate(Page.WORLD)})
        Column(Modifier.padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(20.dp)) {
            SymbolArt(Symbol.LOCK,Modifier.size(70.dp),Gold)
            Text(stringResource(R.string.gate_body),textAlign=TextAlign.Center,color=Muted)
            val holdLabel=stringResource(R.string.hold_lock)
            Box(Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(25.dp)).background(if(held)Mint else Purple)
                .pointerInput(Unit) {detectTapGestures(onPress={holding=true;val released=withTimeoutOrNull(3000) {tryAwaitRelease()};if(released==null)held=true;holding=false})}
                .semantics {contentDescription=holdLabel;onLongClick {held=true;true}}.testTag("gate_hold"),contentAlignment=Alignment.Center) {
                if(holding) CircularProgressIndicator(color=Paper)
                else if(held) SymbolArt(Symbol.CHECK,Modifier.size(30.dp),Ink)
                else Text(holdLabel,fontWeight=FontWeight.Bold)
            }
            if(held) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {Text("$a × $b + $c = ?",fontSize=28.sp,fontWeight=FontWeight.Bold,modifier=Modifier.testTag("gate_question"))}
                OutlinedTextField(answer,{answer=it.take(5);error=false},label={Text(stringResource(R.string.answer))},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true,modifier=Modifier.fillMaxWidth().testTag("gate_answer"))
                if(error) Text(stringResource(R.string.gate_retry),color=Gold)
                ActionButton(stringResource(R.string.verify),{if(answer.toIntOrNull()==a*b+c)vm.navigate(Page.PARENTS) else error=true},Modifier.fillMaxWidth(),Symbol.LOCK,Mint,"gate_verify")
            }
        }
    }
}
@Composable fun Parents(s:UiState,vm:GameViewModel) {
    var confirm by remember {mutableStateOf(false)}
    Column(Modifier.fillMaxSize()) {Header(stringResource(R.string.parents),{vm.navigate(Page.WORLD)})
        Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
            SurfacePanel(Modifier.fillMaxWidth()) {Text(stringResource(R.string.parent_info),fontSize=18.sp);Text(stringResource(R.string.parent_break),color=Muted)}
            ActionButton(stringResource(R.string.about),{vm.navigate(Page.ABOUT)},Modifier.fillMaxWidth(),Symbol.HOME,Purple,"about")
            OutlinedButton(onClick={confirm=true},Modifier.fillMaxWidth().heightIn(min=56.dp).testTag("reset")) {Text(stringResource(R.string.reset_progress),color=Muted)}
            Text(stringResource(R.string.version_label),color=Muted,fontSize=13.sp)
        }
    }
    if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text(stringResource(R.string.reset_title))},text={Text(stringResource(R.string.reset_body))},confirmButton={TextButton(onClick={confirm=false;vm.reset()}) {Text(stringResource(R.string.reset_confirm))}},dismissButton={TextButton(onClick={confirm=false}) {Text(stringResource(R.string.cancel))}})
}
@Composable fun About(vm:GameViewModel) {
    val ctx=LocalContext.current;var failed by remember {mutableStateOf(false)}
    fun open(uri:String) {try {ctx.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))} catch(_:android.content.ActivityNotFoundException) {failed=true} }
    Column(Modifier.fillMaxSize()) {Header(stringResource(R.string.about),{vm.navigate(Page.PARENTS)})
        Column(Modifier.verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
            ToyHero(Modifier.fillMaxWidth().height(160.dp))
            Text(stringResource(R.string.app_name),fontSize=26.sp,fontWeight=FontWeight.Bold)
            Text(stringResource(R.string.version_label),color=Muted)
            Text(stringResource(R.string.about_body))
            SurfacePanel(Modifier.fillMaxWidth()) {Text(stringResource(R.string.privacy_policy),fontWeight=FontWeight.Bold,fontSize=21.sp);Text(stringResource(R.string.privacy_text),color=Muted)}
            if(BuildConfig.PRIVACY_POLICY_URL.startsWith("https://")) TextButton(onClick={open(BuildConfig.PRIVACY_POLICY_URL)}) {Text(stringResource(R.string.privacy_policy))}
            if(BuildConfig.SUPPORT_EMAIL.contains("@")) TextButton(onClick={open("mailto:"+BuildConfig.SUPPORT_EMAIL)}) {Text(stringResource(R.string.support))}
            if(failed) Text(stringResource(R.string.link_failed),color=Gold)
        }
    }
}

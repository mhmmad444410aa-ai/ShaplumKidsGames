package com.mhmmad.shaplumkidsgames.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import com.mhmmad.shaplumkidsgames.*
import com.mhmmad.shaplumkidsgames.R
import com.mhmmad.shaplumkidsgames.engine.*
import com.mhmmad.shaplumkidsgames.engine.Shape

private val BlueNight=Color(0xFF163E8E)
private val BlueDeep=Color(0xFF062E82)
private val Lime=Color(0xFFB1F545)
private val Lemon=Color(0xFFFFD349)
private val SoftWhite=Color(0xFFFFFEF3)
private val Cherries=listOf(Color(0xFFFF547E),Color(0xFF20C3EE),Color(0xFFFFA73D),Color(0xFF36C98A),Color(0xFF9858ED),Color(0xFFFE6D69),Color(0xFF49A5ED),Color(0xFFF7BB29))
private val CherriesDark=listOf(Color(0xFFB51D65),Color(0xFF0973B4),Color(0xFFBF5E16),Color(0xFF0D7C54),Color(0xFF5A31A5),Color(0xFFBA373B),Color(0xFF215AAB),Color(0xFFB67805))

@Composable fun PlayroomBackdrop(modifier:Modifier=Modifier) {
    val inf=rememberInfiniteTransition(label="clouds")
    val drift by inf.animateFloat(0f,1f,infiniteRepeatable(tween(10000,easing=LinearEasing),RepeatMode.Reverse),label="drift")
    Canvas(modifier) {
        val w=size.width;val h=size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0789E6),Color(0xFF2FD8ED),Color(0xFF83EAED),Color(0xFFE8FCBA))))
        fun cloud(x:Float,y:Float,r:Float) {
            drawOval(Color.White.copy(alpha=.75f),Offset(x-r*1.4f,y),Size(r*2.9f,r*.73f))
            drawCircle(Color.White.copy(alpha=.87f),r*.62f,Offset(x-r*.27f,y))
            drawCircle(Color.White.copy(alpha=.9f),r*.76f,Offset(x+r*.5f,y-r*.16f))
        }
        cloud(w*(.17f+drift*.08f),h*.09f,w*.085f)
        cloud(w*(.75f-drift*.07f),h*.32f,w*.075f)
        drawCircle(Color(0xFFFFE984).copy(alpha=.46f),w*.23f,Offset(w*.87f,h*.07f))
        drawOval(Color(0xFF2EB77D),Offset(-w*.4f,h*.87f),Size(w*1.2f,h*.32f))
        drawOval(Color(0xFF50D97B),Offset(w*.18f,h*.89f),Size(w*1.5f,h*.32f))
        repeat(9) { i->
            val p=Offset((i*73%97)/97f*w,(i*53%91)/91f*h)
            drawCircle(SoftWhite.copy(alpha=.68f),w*.005f,p)
        }
    }
}

@Composable private fun JellyButton(label:String,onClick:()->Unit,modifier:Modifier=Modifier,green:Boolean=true,tag:String="",symbol:Symbol=Symbol.PLAY) {
    val high=if(green)Lime else Color(0xFFB37AFB)
    val low=if(green)Color(0xFF38BF5B) else Color(0xFF6F36CF)
    Box(modifier.shadow(13.dp,RoundedCornerShape(28.dp)).clip(RoundedCornerShape(28.dp))
        .background(Brush.verticalGradient(listOf(high,low)))
        .border(3.dp,Color.White,RoundedCornerShape(28.dp))
        .clickable(onClick=onClick).testTag(tag).heightIn(min=64.dp).padding(12.dp),contentAlignment=Alignment.Center) {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) {
            SymbolArt(symbol,Modifier.size(28.dp),if(green)BlueDeep else Color.White)
            Spacer(Modifier.width(9.dp))
            Text(label,color=if(green)BlueDeep else Color.White,fontSize=19.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center)
        }
    }
}

/** Live-drawn world artwork. It never crops an external poster and scales to all devices. */
@Composable private fun ToyCastle(modifier:Modifier=Modifier,animated:Boolean=true) {
    val inf=rememberInfiniteTransition(label="toyCastle")
    val bob by inf.animateFloat(-.025f,.025f,infiniteRepeatable(tween(if(animated)1900 else 1000000,easing=EaseInOutSine),RepeatMode.Reverse),label="bob")
    Canvas(modifier) {
        val w=size.width;val h=size.height
        val sy=h/200f;val sx=w/360f
        fun r(x:Float,y:Float,wi:Float,he:Float,c:Color,rad:Float=10f) = drawRoundRect(c,Offset(x*sx,y*sy),Size(wi*sx,he*sy),androidx.compose.ui.geometry.CornerRadius(rad*sx,rad*sy))
        drawRect(Brush.verticalGradient(listOf(Color(0xFF42C8FF),Color(0xFFB9F5FF))),Offset.Zero,size)
        drawCircle(Color(0xFFFFE482),w*.115f,Offset(w*.84f,h*.18f))
        drawOval(Color.White.copy(alpha=.9f),Offset(w*.05f,h*.18f),Size(w*.28f,h*.13f))
        drawOval(Color.White.copy(alpha=.78f),Offset(w*.66f,h*.37f),Size(w*.26f,h*.11f))
        drawOval(Color(0xFF358F73),Offset(w*.04f,h*.80f),Size(w*.92f,h*.27f))
        drawOval(Color(0xFF66CF63),Offset(-w*.05f,h*.84f),Size(w*1.10f,h*.24f))
        val b=bob*100f
        // Castles, columns and block shapes have strong contrast and highlights.
        r(109f,69f+b,142f,103f,Color(0xFFFFC477))
        r(120f,77f+b,120f,89f,Color(0xFFFFE6A3))
        r(72f,58f+b,52f,117f,Color(0xFFFFD391))
        r(241f,55f+b,53f,121f,Color(0xFFFFD391))
        r(77f,62f+b,40f,106f,Color(0xFFFFE7AA))
        r(248f,61f+b,38f,106f,Color(0xFFFFE7AA))
        fun roof(x:Float,y:Float,width:Float,height:Float,c:Color) {
            val p=Path().apply {moveTo(x*sx,(y+height)*sy);lineTo((x+width/2)*sx,y*sy);lineTo((x+width)*sx,(y+height)*sy);close()};drawPath(p,c)
        }
        roof(63f,26f+b,69f,47f,Color(0xFF974CE9))
        roof(232f,20f+b,71f,49f,Color(0xFF9147E8))
        roof(131f,13f+b,98f,59f,Color(0xFFFF7298))
        r(132f,70f+b,95f,18f,Color(0xFFFFC32E),3f)
        r(146f,94f+b,59f,78f,Color(0xFF9B58B8),27f)
        r(153f,102f+b,45f,67f,Color(0xFF54429E),21f)
        r(166f,63f+b,22f,22f,Color(0xFF5C70C5),9f)
        r(84f,94f+b,21f,29f,Color(0xFF5A84D1),7f)
        r(258f,93f+b,21f,29f,Color(0xFF5A84D1),7f)
        // Three tactile wooden blocks in front of the castle.
        drawCircle(Color(0xFF205D9D).copy(alpha=.36f),22*sx,Offset(67*sx,168*sy))
        drawCircle(Color(0xFF1FD6C3),25*sx,Offset(67*sx,145*sy))
        drawCircle(Color(0xFF8CFFF0).copy(alpha=.55f),9*sx,Offset(57*sx,134*sy))
        val tri=Path().apply {moveTo(270*sx,116*sy);lineTo(233*sx,169*sy);lineTo(307*sx,169*sy);close()}
        drawPath(tri,Color(0xFFFD6E55))
        r(300f,123f,41f,44f,Color(0xFFFFD13C),9f)
        r(306f,128f,27f,7f,Color(0xFFFFE879),5f)
        repeat(6) {i->
            val x=(25+i*58)*sx;val y=(183+(i%2)*9)*sy
            drawCircle(listOf(Color(0xFFFF5C9A),Color(0xFFFFD43D),Color(0xFFB26CF5))[i%3],5*sx,Offset(x,y))
            drawCircle(Color(0xFFFFF5B7),2*sx,Offset(x,y))
        }
    }
}

@Composable private fun ToyIcon(index:Int,modifier:Modifier=Modifier) {
    val first=Piece(Shape.entries[index%Shape.entries.size],index%5)
    val second=Piece(Shape.entries[(index+2)%Shape.entries.size],(index+2)%5)
    Box(modifier,contentAlignment=Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color.White.copy(alpha=.25f),size.width*.36f,Offset(size.width*.5f,size.height*.5f))
            drawCircle(Color.White.copy(alpha=.28f),size.width*.045f,Offset(size.width*.15f,size.height*.18f))
            drawCircle(Color.White.copy(alpha=.28f),size.width*.035f,Offset(size.width*.82f,size.height*.77f))
        }
        ShapeArt(first,Modifier.align(Alignment.CenterStart).padding(start=11.dp).size(68.dp).rotate(-16f),glow=true)
        ShapeArt(second,Modifier.align(Alignment.CenterEnd).padding(end=8.dp,top=24.dp).size(64.dp).rotate(13f),glow=true)
        if(index==6)SymbolArt(Symbol.STAR,Modifier.align(Alignment.TopCenter).padding(top=8.dp).size(30.dp),Lemon)
    }
}

@Composable fun ToyGameBanner(index:Int,modifier:Modifier=Modifier) {
    Box(modifier.clip(RoundedCornerShape(25.dp))
        .background(Brush.verticalGradient(listOf(Cherries[index],CherriesDark[index])))
        .border(3.dp,Color.White,RoundedCornerShape(25.dp)),contentAlignment=Alignment.Center) {
        ToyIcon(index,Modifier.fillMaxHeight().fillMaxWidth(.67f))
    }
}

@Composable private fun GameTile(m:Mode,vm:GameViewModel) {
    val n=m.ordinal
    val high=Cherries[n];val low=CherriesDark[n]
    Column(Modifier.fillMaxWidth().shadow(13.dp,RoundedCornerShape(30.dp))
        .clip(RoundedCornerShape(30.dp)).background(Brush.verticalGradient(listOf(high,low)))
        .border(3.dp,Color.White,RoundedCornerShape(30.dp))
        .clickable {vm.start(n*15)}.testTag("mode_$n"),horizontalAlignment=Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().height(132.dp).padding(8.dp).clip(RoundedCornerShape(23.dp))
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha=.35f),Color.White.copy(alpha=.05f))))) {
            ToyIcon(n,Modifier.fillMaxSize())
            Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(33.dp)
                .clip(CircleShape).background(Lemon).border(2.dp,Color.White,CircleShape),contentAlignment=Alignment.Center) {
                SymbolArt(Symbol.PLAY,Modifier.size(16.dp),BlueDeep)
            }
        }
        Text(stringResource(ModeNames[n]),modifier=Modifier.padding(horizontal=5.dp),color=Color.White,
            fontSize=16.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center,minLines=2,maxLines=2,lineHeight=18.sp)
        // Secondary levels entry: children can play now or choose any level.
        TextButton(onClick={vm.mode(m)},modifier=Modifier.fillMaxWidth().height(45.dp).testTag("levels_$n"),contentPadding=PaddingValues(0.dp)) {
            Text(stringResource(R.string.v13_choose_level),color=SoftWhite,fontSize=13.sp,fontWeight=FontWeight.Black)
        }
    }
}

@Composable private fun TopBar(s:UiState,vm:GameViewModel) {
    Row(Modifier.fillMaxWidth().padding(horizontal=15.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.brand),fontSize=38.sp,color=Lemon,fontWeight=FontWeight.Black,
                style=androidx.compose.ui.text.TextStyle(shadow=Shadow(BlueDeep,Offset(3f,5f),4f)),maxLines=1)
            Text(stringResource(R.string.v13_kids_games),fontSize=15.sp,fontWeight=FontWeight.ExtraBold,color=SoftWhite)
        }
        Box(Modifier.size(56.dp).clip(CircleShape).background(Color.White).border(3.dp,Lemon,CircleShape),contentAlignment=Alignment.Center) {
            IconControl(Symbol.SETTINGS,stringResource(R.string.settings),{vm.navigate(Page.SETTINGS)},"settings")
        }
    }
}

@Composable fun PremiumWorld(s:UiState,vm:GameViewModel) {
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            TopBar(s,vm)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
                Box(Modifier.fillMaxWidth().height(211.dp).shadow(17.dp,RoundedCornerShape(34.dp))
                    .clip(RoundedCornerShape(34.dp)).border(4.dp,SoftWhite,RoundedCornerShape(34.dp))) {
                    ToyCastle(Modifier.fillMaxSize(),s.saved.motion)
                    Box(Modifier.align(Alignment.BottomEnd).padding(10.dp).clip(RoundedCornerShape(18.dp))
                        .background(BlueNight.copy(alpha=.91f)).padding(horizontal=12.dp,vertical=7.dp)) {
                        Text(stringResource(R.string.offline_badge),fontWeight=FontWeight.Black,fontSize=13.sp,color=SoftWhite)
                    }
                }
                JellyButton(stringResource(R.string.v13_play_now),{vm.start(0)},Modifier.fillMaxWidth(),green=true,tag="play_now")
                if(s.saved.session!=null) JellyButton(stringResource(R.string.resume),vm::resume,Modifier.fillMaxWidth(),green=false,tag="resume")
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Text(stringResource(R.string.v13_pick_a_game),Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Black,color=BlueDeep)
                    Text("8 / 8",fontSize=16.sp,fontWeight=FontWeight.Black,color=BlueDeep)
                }
                Mode.entries.chunked(2).forEach {pair->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        pair.forEach {m-> Box(Modifier.weight(1f)){GameTile(m,vm)} }
                    }
                }
                JellyButton(stringResource(R.string.progress),{vm.navigate(Page.PROGRESS)},Modifier.fillMaxWidth(),green=false,tag="progress",symbol=Symbol.TROPHY)
                Spacer(Modifier.height(12.dp))
            }
            TextButton(onClick={vm.navigate(Page.GATE)},modifier=Modifier.fillMaxWidth().testTag("parents")) {
                Text(stringResource(R.string.parents),fontWeight=FontWeight.Bold,color=BlueNight,fontSize=12.sp)
            }
        }
    }
}

@Composable private fun PageTitle(title:String,back:()->Unit,subtitle:String="") {
    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        IconControl(Symbol.BACK,stringResource(R.string.back),back,"back")
        Column(Modifier.weight(1f)) {
            Text(title,fontSize=22.sp,fontWeight=FontWeight.Black,color=BlueDeep,maxLines=1,overflow=TextOverflow.Ellipsis)
            if(subtitle.isNotEmpty())Text(subtitle,fontSize=13.sp,color=BlueNight,fontWeight=FontWeight.Bold)
        }
    }
}

@Composable fun PremiumModes(s:UiState,vm:GameViewModel) {
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            PageTitle(stringResource(R.string.v13_pick_a_game),{vm.navigate(Page.WORLD)},stringResource(R.string.v13_all_open))
            LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize(),contentPadding=PaddingValues(14.dp),horizontalArrangement=Arrangement.spacedBy(13.dp),verticalArrangement=Arrangement.spacedBy(13.dp)) {
                items(Mode.entries) {m->GameTile(m,vm)}
            }
        }
    }
}

@Composable fun PremiumMap(s:UiState,vm:GameViewModel) {
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            PageTitle(stringResource(ModeNames[s.mode.ordinal]),{vm.navigate(Page.MODES)},stringResource(R.string.v13_levels_open))
            LazyVerticalGrid(GridCells.Fixed(3),Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),horizontalArrangement=Arrangement.spacedBy(12.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
                item(span={GridItemSpan(3)}) {
                    Box(Modifier.fillMaxWidth().height(126.dp).clip(RoundedCornerShape(30.dp))
                        .background(Brush.verticalGradient(listOf(Cherries[s.mode.ordinal],CherriesDark[s.mode.ordinal])))
                        .border(3.dp,Color.White,RoundedCornerShape(30.dp)),contentAlignment=Alignment.Center) {
                        ToyIcon(s.mode.ordinal,Modifier.fillMaxWidth(.60f).fillMaxHeight())
                    }
                }
                items(15) {n->
                    val id=s.mode.ordinal*15+n
                    val score=s.saved.scores[id]?:0
                    val tint=Cherries[(n+s.mode.ordinal)%8]
                    Box(Modifier.fillMaxWidth().aspectRatio(.92f).shadow(8.dp,CircleShape).clip(CircleShape)
                        .background(Brush.verticalGradient(listOf(SoftWhite,tint)))
                        .border(4.dp,Color.White,CircleShape)
                        .clickable {vm.start(id)}.testTag("level_$n"),contentAlignment=Alignment.Center) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            Text(number(n+1),fontSize=34.sp,fontWeight=FontWeight.Black,color=BlueDeep)
                            Row(horizontalArrangement=Arrangement.spacedBy(1.dp)) {
                                repeat(3) {i-> SymbolArt(Symbol.STAR,Modifier.size(16.dp),if(i<score)Lemon else Color.White.copy(alpha=.75f)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable fun PremiumSuccess(s:UiState,vm:GameViewModel,sound:(Boolean)->Unit) {
    val game=s.saved.session?:return
    LaunchedEffect(game.levelId){sound(true)}
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        CelebrationBurst(s.saved.motion,Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(20.dp)) {
            Spacer(Modifier.height(12.dp))
            Box(Modifier.size(184.dp).shadow(14.dp,CircleShape).background(Brush.radialGradient(listOf(Lemon,Color(0xFFFF8A3D))),CircleShape)
                .border(5.dp,Color.White,CircleShape),contentAlignment=Alignment.Center) {
                SymbolArt(Symbol.TROPHY,Modifier.size(115.dp),Color.White)
            }
            Text(stringResource(R.string.success_title),fontSize=32.sp,color=BlueDeep,fontWeight=FontWeight.Black,textAlign=TextAlign.Center,modifier=Modifier.testTag("success"))
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {repeat(3){i->
                var visible by remember(game.levelId){mutableStateOf(!s.saved.motion)}
                LaunchedEffect(game.levelId){kotlinx.coroutines.delay(110L*i);visible=true}
                val scale by animateFloatAsState(if(visible)1f else .1f,spring(dampingRatio=.44f),label="reward")
                SymbolArt(Symbol.STAR,Modifier.size(61.dp).scale(scale),if(i<Engine.stars(game))Lemon else Color.White.copy(alpha=.67f))
            }}
            Text(stringResource(R.string.success_body),fontSize=17.sp,color=BlueNight,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
            JellyButton(stringResource(R.string.next),vm::next,Modifier.fillMaxWidth(),green=true,tag="next")
            JellyButton(stringResource(R.string.replay),{vm.start(game.levelId)},Modifier.fillMaxWidth(),green=false,tag="replay",symbol=Symbol.ROTATE)
            TextButton(onClick={vm.navigate(Page.WORLD)}) {Text(stringResource(R.string.home),fontWeight=FontWeight.Black,color=BlueNight)}
        }
    }
}

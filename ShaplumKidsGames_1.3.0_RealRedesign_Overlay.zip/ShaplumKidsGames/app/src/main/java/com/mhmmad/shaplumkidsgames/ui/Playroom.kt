package com.mhmmad.shaplumkidsgames.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.mhmmad.shaplumkidsgames.*
import com.mhmmad.shaplumkidsgames.R
import com.mhmmad.shaplumkidsgames.engine.*

private val SkyBlue=Color(0xFF26B8EF)
private val RoyalBlue=Color(0xFF1850AE)
private val Night=Color(0xFF153A76)
private val ToyYellow=Color(0xFFFFD243)
private val SpringGreen=Color(0xFF48D873)
private val ToyPink=Color(0xFFFA58A9)
private val CloudWhite=Color(0xFFFFFEF9)
private val Candy=listOf(Color(0xFFFA68B1),Color(0xFF25BAE9),Color(0xFFFFA73D),Color(0xFF52D56E),Color(0xFF9266EE),Color(0xFFFC7776),Color(0xFF4D89EB),Color(0xFFFFC63D))
private val CandyDeep=listOf(Color(0xFFAA2680),Color(0xFF176EA8),Color(0xFFCB6518),Color(0xFF159A53),Color(0xFF572DB7),Color(0xFFCA416A),Color(0xFF2555A8),Color(0xFFD18E0B))

@Composable fun PlayroomBackdrop(modifier:Modifier=Modifier) {
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0E9FEC),Color(0xFF66DDF5),Color(0xFFCDFAEE),Color(0xFFFFEEBE)),startY=0f,endY=size.height))
        // Cloud clusters, leaves and soft toy-land hills. The decor never intercepts gestures.
        val w=size.width;val h=size.height
        fun cloud(x:Float,y:Float,r:Float) {
            drawOval(Color.White.copy(alpha=.86f),Offset(x-r*1.4f,y),Size(r*3f,r*.9f))
            drawCircle(Color.White.copy(alpha=.89f),r*.55f,Offset(x,y))
            drawCircle(Color.White.copy(alpha=.89f),r*.65f,Offset(x+r*.69f,y-r*.16f))
        }
        cloud(w*.18f,h*.075f,w*.10f);cloud(w*.79f,h*.18f,w*.09f)
        drawOval(Color(0xFFA7F2A1).copy(alpha=.53f),Offset(-w*.5f,h*.67f),Size(w*1.15f,h*.48f))
        drawOval(Color(0xFF72E3B1).copy(alpha=.54f),Offset(w*.4f,h*.74f),Size(w*1.16f,h*.48f))
        repeat(9) {i->
            val x=(i*73%91)/91f*w;val y=(i*49%95)/95f*h
            drawCircle(Color.White.copy(alpha=.68f),w*.007f,Offset(x,y))
        }
    }
}

@Composable private fun PlayroomButton(label:String,onClick:()->Unit,color:Color=ToyYellow,modifier:Modifier=Modifier,tag:String="",symbol:Symbol=Symbol.PLAY) {
    Box(modifier.shadow(11.dp,RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp))
        .background(Brush.verticalGradient(listOf(color,if(color==SpringGreen)Color(0xFF17AE72) else if(color==ToyYellow)Color(0xFFFFAF32) else Color(0xFF6D37CF))))
        .border(3.dp,Color.White.copy(alpha=.88f),RoundedCornerShape(26.dp))
        .clickable(onClick=onClick).testTag(tag).heightIn(min=62.dp).padding(horizontal=14.dp,vertical=8.dp),contentAlignment=Alignment.Center) {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center) {
            SymbolArt(symbol,Modifier.size(28.dp),if(color==SpringGreen||color==ToyYellow)Night else Color.White)
            Spacer(Modifier.width(9.dp))
            Text(label,color=if(color==SpringGreen||color==ToyYellow)Night else Color.White,fontSize=19.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center)
        }
    }
}

@Composable private fun WorldTitle(s:UiState,vm:GameViewModel) {
    Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.brand),fontSize=31.sp,fontWeight=FontWeight.Black,color=ToyYellow,
                maxLines=1,softWrap=false,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                style=androidx.compose.ui.text.TextStyle(shadow=Shadow(Color(0xFF1546A7),Offset(2f,3f),3f)))
            Text(stringResource(R.string.v13_kids_games),color=Color.White,fontWeight=FontWeight.ExtraBold,fontSize=17.sp,
                maxLines=1,softWrap=false)
        }
        Box(Modifier.size(62.dp).shadow(7.dp,CircleShape).clip(CircleShape).background(Color.White).border(3.dp,ToyYellow,CircleShape)) {
            IconControl(Symbol.SETTINGS,stringResource(R.string.settings),{vm.navigate(Page.SETTINGS)},"settings")
        }
    }
}

@Composable private fun WorldHero(s:UiState,vm:GameViewModel) {
    Column(Modifier.fillMaxWidth().shadow(12.dp,RoundedCornerShape(35.dp))
        .clip(RoundedCornerShape(35.dp)).background(Color(0xFF36BCEB))
        .border(4.dp,Color.White,RoundedCornerShape(35.dp))) {
        // The entire 3D toy artwork is visible. No Crop; no half-images.
        Image(painterResource(R.drawable.v13_hero_full),contentDescription=null,
            modifier=Modifier.fillMaxWidth().height(245.dp).background(Brush.horizontalGradient(listOf(Color(0xFFB4F8F0),Color(0xFF72DAFA)))),contentScale=ContentScale.Fit)
        Row(Modifier.fillMaxWidth().background(RoyalBlue).padding(horizontal=13.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
            Text(stringResource(R.string.offline_badge),fontWeight=FontWeight.Black,fontSize=15.sp,color=Color.White)
            Row(verticalAlignment=Alignment.CenterVertically) {
                SymbolArt(Symbol.STAR,Modifier.size(23.dp),ToyYellow);Spacer(Modifier.width(4.dp))
                Text(number(s.saved.scores.values.sum()),fontWeight=FontWeight.Black,color=Color.White)
            }
        }
    }
}

@Composable fun PremiumWorld(s:UiState,vm:GameViewModel) {
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            WorldTitle(s,vm)
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal=15.dp),verticalArrangement=Arrangement.spacedBy(17.dp)) {
                WorldHero(s,vm)
                PlayroomButton(stringResource(R.string.v13_play_now),{vm.navigate(Page.MODES)},SpringGreen,Modifier.fillMaxWidth(),"all_games")
                if(s.saved.session!=null) PlayroomButton(stringResource(R.string.resume),vm::resume,ToyYellow,Modifier.fillMaxWidth(),"resume")
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween) {
                    Column {
                        Text(stringResource(R.string.v13_pick_a_game),fontSize=25.sp,fontWeight=FontWeight.Black,color=Night)
                        Text(stringResource(R.string.v13_all_open),fontSize=14.sp,fontWeight=FontWeight.Bold,color=RoyalBlue)
                    }
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha=.90f)).padding(12.dp)) {
                        Text("8 / 8",fontSize=15.sp,fontWeight=FontWeight.Black,color=Night)
                    }
                }
                Mode.entries.chunked(2).forEach { pair->
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        pair.forEach { m ->Box(Modifier.weight(1f)) {PremiumGameCard(m,vm)} }
                    }
                }
                PlayroomButton(stringResource(R.string.progress),{vm.navigate(Page.PROGRESS)},Color(0xFF9455ED),Modifier.fillMaxWidth(),"progress",Symbol.TROPHY)
                Spacer(Modifier.height(48.dp))
            }
            // Parent gate stays unobtrusive and separate from children's primary choices.
            TextButton(onClick={vm.navigate(Page.GATE)},modifier=Modifier.fillMaxWidth().testTag("parents")) {
                Text(stringResource(R.string.parents),fontSize=13.sp,color=Night,fontWeight=FontWeight.Bold)
            }
        }
    }
}

@Composable private fun PremiumGameCard(m:Mode,vm:GameViewModel) {
    val n=m.ordinal
    Column(Modifier.fillMaxWidth().shadow(10.dp,RoundedCornerShape(27.dp))
        .clip(RoundedCornerShape(27.dp))
        .background(Brush.verticalGradient(listOf(Candy[n],CandyDeep[n])))
        .border(3.dp,Color.White,RoundedCornerShape(27.dp))
        .clickable {vm.mode(m)}.testTag("mode_$n").padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        // Fixed aspect-ratio artwork with letterboxing, not cropping: the whole illustration remains visible.
        Box(Modifier.fillMaxWidth().aspectRatio(1.13f).clip(RoundedCornerShape(21.dp))
            .background(Color(0xFFF7FFFF)).border(2.dp,Color.White,RoundedCornerShape(21.dp))) {
            PremiumModePicture(n,Modifier.fillMaxSize())
            Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(32.dp)
                .background(ToyYellow,CircleShape).border(2.dp,Color.White,CircleShape),contentAlignment=Alignment.Center) {
                SymbolArt(Symbol.PLAY,Modifier.size(17.dp),Night)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(ModeNames[n]),fontSize=17.sp,fontWeight=FontWeight.Black,color=Color.White,
            textAlign=TextAlign.Center,minLines=2,maxLines=2,lineHeight=19.sp)
        Spacer(Modifier.height(3.dp))
        Text(stringResource(R.string.v13_levels_open),fontWeight=FontWeight.ExtraBold,color=Color.White.copy(alpha=.96f),fontSize=12.sp,
            maxLines=1,softWrap=false,overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
    }
}

@Composable fun PremiumModePicture(index:Int,modifier:Modifier=Modifier) {
    val id=when(index) {
        0->R.drawable.v13_preview_0;1->R.drawable.v13_preview_1;2->R.drawable.v13_preview_2;3->R.drawable.v13_preview_3
        4->R.drawable.v13_preview_4;5->R.drawable.v13_preview_5;6->R.drawable.v13_preview_6;else->R.drawable.v13_preview_7
    }
    Image(painterResource(id),contentDescription=null,modifier=modifier.background(Color.White),contentScale=ContentScale.Fit)
}

@Composable private fun PremiumHeader(title:String,back:()->Unit,caption:String="") {
    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        IconControl(Symbol.BACK,stringResource(R.string.back),back,"back")
        Column(Modifier.weight(1f)) {
            Text(title,fontWeight=FontWeight.Black,color=Night,fontSize=22.sp,maxLines=1,
                overflow=androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            if(caption.isNotBlank())Text(caption,fontWeight=FontWeight.Bold,color=RoyalBlue,fontSize=13.sp)
        }
    }
}

@Composable fun PremiumModes(s:UiState,vm:GameViewModel) {
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            PremiumHeader(stringResource(R.string.v13_pick_a_game),{vm.navigate(Page.WORLD)},stringResource(R.string.v13_all_open))
            LazyVerticalGrid(GridCells.Fixed(2),modifier=Modifier.fillMaxSize(),
                contentPadding=PaddingValues(start=15.dp,end=15.dp,top=15.dp,bottom=28.dp),
                horizontalArrangement=Arrangement.spacedBy(14.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
                items(Mode.entries) {m-> PremiumGameCard(m,vm)}
            }
        }
    }
}

@Composable fun PremiumMap(s:UiState,vm:GameViewModel) {
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize()) {
            PremiumHeader(stringResource(ModeNames[s.mode.ordinal]),{vm.navigate(Page.MODES)},stringResource(R.string.v13_levels_open))
            LazyVerticalGrid(GridCells.Fixed(3),modifier=Modifier.weight(1f),
                contentPadding=PaddingValues(14.dp),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalArrangement=Arrangement.spacedBy(16.dp)) {
                item(span={GridItemSpan(3)}) {
                    Column(Modifier.fillMaxWidth(),horizontalAlignment=Alignment.CenterHorizontally) {
                        Box(Modifier.fillMaxWidth().height(175.dp).shadow(10.dp,RoundedCornerShape(31.dp))
                            .background(Color.White).border(4.dp,ToyYellow,RoundedCornerShape(31.dp)).padding(10.dp)) {
                            PremiumModePicture(s.mode.ordinal,Modifier.fillMaxSize())
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(stringResource(R.string.v13_choose_level),fontWeight=FontWeight.Black,color=Night,fontSize=25.sp)
                    }
                }
                items(15) { n->
                    val id=s.mode.ordinal*15+n
                    val score=s.saved.scores[id]?:0
                    val tone=Candy[(n+s.mode.ordinal)%8]
                    val deep=CandyDeep[(n+s.mode.ordinal)%8]
                    Column(Modifier.fillMaxWidth().aspectRatio(.90f).shadow(8.dp,RoundedCornerShape(26.dp))
                        .clip(RoundedCornerShape(26.dp)).background(Brush.verticalGradient(listOf(tone,deep)))
                        .border(3.dp,Color.White,RoundedCornerShape(26.dp)).clickable {vm.start(id)}
                        .testTag("level_$n").padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                        Text(number(n+1),fontSize=37.sp,color=Color.White,fontWeight=FontWeight.Black,
                            style=androidx.compose.ui.text.TextStyle(shadow=Shadow(Night.copy(alpha=.40f),Offset(2f,4f),4f)))
                        Spacer(Modifier.height(3.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(2.dp)) {
                            repeat(3) {k->SymbolArt(Symbol.STAR,Modifier.size(19.dp),if(k<score)ToyYellow else Color.White.copy(alpha=.55f))}
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(stringResource(DifficultyNames[n/5]),fontSize=11.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
                    }
                }
            }
        }
    }
}

@Composable fun PremiumSuccess(s:UiState,vm:GameViewModel,sound:(Boolean)->Unit) {
    val game=s.saved.session?:return
    LaunchedEffect(game.levelId) {sound(true)}
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        CelebrationBurst(s.saved.motion,Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(20.dp)) {
            Spacer(Modifier.height(9.dp))
            Box(Modifier.size(200.dp).shadow(18.dp,CircleShape).background(Brush.radialGradient(listOf(ToyYellow,Color(0xFFFF8D39))),CircleShape)
                .border(6.dp,Color.White,CircleShape),contentAlignment=Alignment.Center) {
                SymbolArt(Symbol.TROPHY,Modifier.size(112.dp),Color.White)
                SymbolArt(Symbol.STAR,Modifier.align(Alignment.TopEnd).padding(15.dp).size(42.dp),Color.White)
            }
            Text(stringResource(R.string.success_title),fontSize=32.sp,fontWeight=FontWeight.Black,color=Night,textAlign=TextAlign.Center,modifier=Modifier.testTag("success"))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {repeat(3){i->
                var go by remember(game.levelId){mutableStateOf(!s.saved.motion)}
                LaunchedEffect(game.levelId){kotlinx.coroutines.delay(i*130L);go=true}
                val z by animateFloatAsState(if(go)1f else .1f,spring(dampingRatio=.40f),label="cheer")
                SymbolArt(Symbol.STAR,Modifier.size(66.dp).scale(z),if(i<Engine.stars(game))ToyYellow else Color.White.copy(alpha=.7f))
            }}
            Text(stringResource(R.string.success_body),fontSize=18.sp,fontWeight=FontWeight.Bold,color=Night,textAlign=TextAlign.Center)
            PlayroomButton(stringResource(R.string.next),vm::next,SpringGreen,Modifier.fillMaxWidth(),"next")
            PlayroomButton(stringResource(R.string.replay),{vm.start(game.levelId)},Color(0xFF9754EA),Modifier.fillMaxWidth(),"replay",Symbol.ROTATE)
            TextButton(onClick={vm.navigate(Page.WORLD)}) {Text(stringResource(R.string.home),fontWeight=FontWeight.Black,color=Night)}
        }
    }
}

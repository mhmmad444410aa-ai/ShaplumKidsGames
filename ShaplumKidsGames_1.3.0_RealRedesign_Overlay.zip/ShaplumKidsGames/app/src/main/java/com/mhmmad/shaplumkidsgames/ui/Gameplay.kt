package com.mhmmad.shaplumkidsgames.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.mhmmad.shaplumkidsgames.*
import com.mhmmad.shaplumkidsgames.R
import com.mhmmad.shaplumkidsgames.engine.*
import com.mhmmad.shaplumkidsgames.engine.Shape
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun Gameplay(state:UiState,vm:GameViewModel,sound:(Boolean)->Unit) {
    val s=state.saved.session ?: return;val l=Levels.get(s.levelId)
    var selected by remember(s.levelId) {mutableIntStateOf(-1)}
    var hint by remember(s.levelId) {mutableStateOf<Action?>(null)}
    var feedback by remember(s.levelId) {mutableStateOf(false)}
    LaunchedEffect(s.mistakes) {if(s.mistakes>0) {feedback=true;delay(1500);feedback=false}}
    LaunchedEffect(s.flipped,state.paused) {if(s.flipped.size==2 && !state.paused) {delay(1000);vm.action(Action.HidePair)}}
    val currentAction by rememberUpdatedState<(Action)->Unit> { a -> vm.action(a);if(a !is Action.Hint && a !is Action.HidePair)sound(false);hint=null }
    val instruction=when(l.mode) {
        Mode.SHAPES->R.string.shape_help;Mode.COLORS->if(l.rule==1)R.string.color_shape_help else R.string.color_help
        Mode.PATTERNS->R.string.pattern_help;Mode.SHADOWS->R.string.shadow_help
        Mode.MAZE->if(l.maze?.key!=null)R.string.maze_key_help else R.string.maze_help
        Mode.ARCHITECT->R.string.architect_help;Mode.MEMORY->R.string.memory_help
        Mode.LOGIC->listOf(R.string.logic_odd_shape,R.string.logic_odd_color,R.string.logic_count,R.string.logic_both,R.string.logic_mix)[l.rule]
    }
    Column(Modifier.fillMaxSize().testTag("gameplay")) {
        Header(stringResource(ModeNames[l.mode.ordinal]),{vm.pause(true)}) {IconControl(Symbol.PAUSE,stringResource(R.string.pause),{vm.pause(true)},"pause")}
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            val landscape=maxWidth>maxHeight*1.15f
            @Composable fun Info(modifier:Modifier) {
                Column(modifier.padding(horizontal=16.dp,vertical=7.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                        Text(stringResource(R.string.level,number(l.number)),fontWeight=FontWeight.Bold,fontSize=19.sp)
                        Text(stringResource(DifficultyNames[l.difficulty]),color=Gold,fontSize=13.sp)
                    }
                    LinearProgressIndicator(progress={Engine.progress(s)},modifier=Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp)),color=Mint,trackColor=Purple.copy(alpha=.13f),drawStopIndicator={})
                    Text(stringResource(instruction),fontSize=16.sp,fontWeight=FontWeight.ExtraBold,textAlign=TextAlign.Center,color=Ink,modifier=Modifier.testTag("instruction"))
                    if(l.difficulty==0 && l.mode in listOf(Mode.SHAPES,Mode.COLORS,Mode.SHADOWS,Mode.ARCHITECT))
                        Text(stringResource(R.string.one_tap_help),fontSize=14.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,color=Color(0xFF6529D3))
                    if(landscape) IslandArt(l.mode.ordinal,Modifier.fillMaxWidth().height(110.dp),state.saved.motion)
                }
            }
            @Composable fun Controls(modifier:Modifier) {
                Column(modifier.padding(horizontal=16.dp,vertical=8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    if(feedback) Text(stringResource(R.string.try_again),color=Gold,fontSize=14.sp,textAlign=TextAlign.Center)
                    else if(hint!=null) Text(stringResource(R.string.hint_message),color=Gold,fontSize=14.sp,textAlign=TextAlign.Center)
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        ActionButton(stringResource(R.string.hint),{val h=Engine.hint(s);hint=h;if(h is Action.Place)selected=h.piece;if(h is Action.Rotate)selected=h.piece;vm.action(Action.Hint)},Modifier.weight(1f),Symbol.HINT,Purple,"hint")
                        if(l.mode==Mode.SHADOWS && l.difficulty>0) IconControl(Symbol.ROTATE,stringResource(R.string.rotate),{
                            val piece=if(selected>=0 && selected !in s.placed)selected else l.pieces.indices.firstOrNull {it !in s.placed} ?:0
                            selected=piece;currentAction(Action.Rotate(piece))
                        },"rotate")
                    }
                }
            }
            if(landscape) Row(Modifier.fillMaxSize(),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.width(260.dp).fillMaxHeight().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.SpaceBetween) {Info(Modifier.fillMaxWidth());Controls(Modifier.fillMaxWidth())}
                Box(Modifier.weight(1f).fillMaxHeight().padding(8.dp),contentAlignment=Alignment.Center) {Board(l,s,selected,{selected=it},hint,currentAction)}
            } else Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally) {
                Info(Modifier.fillMaxWidth())
                Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal=6.dp),contentAlignment=Alignment.Center) {Board(l,s,selected,{selected=it},hint,currentAction)}
                Controls(Modifier.fillMaxWidth())
            }
        }
    }
    if(state.paused) AlertDialog(onDismissRequest={vm.pause(false)},title={Text(stringResource(R.string.paused))},text={IslandArt(l.mode.ordinal,Modifier.fillMaxWidth().height(140.dp),false)},confirmButton={TextButton(onClick={vm.pause(false)},Modifier.testTag("unpause")) {Text(stringResource(R.string.keep_playing))}},dismissButton={Column {
        TextButton(onClick={vm.pause(false);vm.start(s.levelId)},Modifier.testTag("restart")) {Text(stringResource(R.string.replay))}
        TextButton(onClick={vm.navigate(Page.WORLD)},Modifier.testTag("pause_home")) {Text(stringResource(R.string.home))}
    }})
}

@Composable
private fun Board(l:Level,s:Session,selected:Int,select:(Int)->Unit,hint:Action?,action:(Action)->Unit) {
    BoxWithConstraints(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
        val side=minOf(maxWidth,maxHeight)
        // Geometric teaching coordinates stay LTR in every language, including Arabic.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.size(side).shadow(10.dp,RoundedCornerShape(32.dp)).clip(RoundedCornerShape(32.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF),Color(0xFFFFF8D8),Color(0xFFFFDFEC))))
                .border(4.dp,Color(0xFFB05BF7),RoundedCornerShape(32.dp)).testTag("board")) {
                val unit=side/1000
                Canvas(Modifier.fillMaxSize()) {
                    repeat(12) { i ->
                        val x=((i*83+33)%100)/100f*size.width
                        val y=((i*47+11)%100)/100f*size.height
                        drawCircle(listOf(Gold,Mint,Coral,Purple)[i%4].copy(alpha=.11f),size.width*.02f,Offset(x,y))
                    }
                }
                when(l.mode) {
                    Mode.SHAPES,Mode.COLORS,Mode.SHADOWS,Mode.ARCHITECT -> PlacementBoard(l,s,selected,select,hint,action,unit)
                    Mode.MEMORY -> MemoryBoard(l,s,hint,action,unit)
                    Mode.MAZE -> MazeBoard(l,s,hint,action,unit)
                    Mode.PATTERNS -> PatternBoard(l,s,hint,action,unit)
                    Mode.LOGIC -> LogicBoard(l,s,hint,action,unit)
                }
            }
        }
    }
}
private fun sourcePosition(i:Int,count:Int):Offset {
    val cols=if(count<=3)count else 4
    val rows=(count+cols-1)/cols
    val row=i/cols;val actualCols=minOf(cols,count-row*cols)
    return Offset(500f+(i%cols-(actualCols-1)/2f)*218f,if(rows==3) 645f+row*150f else 715f+row*178f)
}
private fun targetPosition(l:Level,i:Int):Offset {
    if(l.mode==Mode.ARCHITECT) {
        val bp=l.blueprint[i];val minY=l.blueprint.minOf {it.y};val maxY=l.blueprint.maxOf {it.y}
        val step=minOf(110f,400f/(maxY-minY).coerceAtLeast(1))
        return Offset(120f+bp.x*190f,80f+(bp.y-minY)*step)
    }
    val count=l.targets.size;val cols=if(count<=4)count else 4
    val actualCols=minOf(cols,count-(i/cols)*cols)
    return Offset(500f+(i%cols-(actualCols-1)/2f)*220f,if(l.mode==Mode.COLORS)310f else 200f+(i/cols)*230f)
}
@Composable
private fun PlacementBoard(l:Level,s:Session,selected:Int,select:(Int)->Unit,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val targets=if(l.mode==Mode.ARCHITECT)l.blueprint.map {it.piece} else l.targets
    val targetSize=if(l.mode==Mode.COLORS)250f else if(l.mode==Mode.ARCHITECT)215f else 235f
    // Blueprints occupy a 3D scaffold; larger touch regions remain separate from the drawn blocks.
    targets.forEachIndexed { i,p ->
        val pos=targetPosition(l,i);val filled=if(l.mode==Mode.COLORS)false else i in s.placed.values
        val matchedScale by animateFloatAsState(if(filled)1f else .94f,spring(dampingRatio=.5f,stiffness=500f),label="matchPop")
        val available=l.mode!=Mode.ARCHITECT || l.blueprint[i].support==-1 || l.blueprint[i].support in s.placed.values
        val targetLabel=stringResource(R.string.target_access,number(i+1))
        Box(Modifier.offset(unit*(pos.x-targetSize/2),unit*(pos.y-targetSize/2)).size(unit*targetSize)
            .clip(RoundedCornerShape(20.dp)).background(if(l.mode==Mode.COLORS)Palette[p.color].copy(alpha=.20f) else Color.Transparent)
            .border(if(hint is Action.Place && hint.target==i)3.dp else 1.dp,if(hint is Action.Place && hint.target==i)Gold else if(available)Purple.copy(alpha=.16f) else Color.Transparent,RoundedCornerShape(20.dp))
            .clickable {if(selected>=0)action(Action.Place(selected,i))}.testTag("target_$i").semantics {contentDescription=targetLabel},contentAlignment=Alignment.Center) {
            if(l.mode==Mode.COLORS) {
                Canvas(Modifier.fillMaxSize()) {drawRoundRect(Palette[p.color],Offset(size.width*.08f,size.height*.75f),Size(size.width*.84f,size.height*.12f),CornerRadius(8f));val total=s.placed.values.count {it==i};repeat(total) {j ->drawCircle(Palette[p.color],size.width*.025f,Offset(size.width*(.23f+j*.11f),size.height*.91f))}}
                ShapeArt(p,Modifier.fillMaxSize().padding(12.dp),silhouette=false,faded=l.rule==0)
            } else ShapeArt(p,Modifier.fillMaxSize().scale(matchedScale).alpha(if(available||filled)1f else .30f),silhouette=l.mode==Mode.SHADOWS && !filled,faded=!filled && l.mode!=Mode.SHADOWS,glow=hint is Action.Place && hint.target==i)
        }
    }
    // Thin shelf keeps the source tray visually separate from the destinations.
    Canvas(Modifier.fillMaxSize()) {drawLine(Purple.copy(alpha=.18f),Offset(size.width*.06f,size.height*.59f),Offset(size.width*.94f,size.height*.59f),2f)}
    l.pieces.forEachIndexed { i,p ->
        if(i !in s.placed) {
            val pos=sourcePosition(i,l.pieces.size);val tileSize=205f
            var dragging by remember(s.levelId,i) {mutableStateOf(false)}
            var delta by remember(s.levelId,i) {mutableStateOf(Offset.Zero)}
            val density=LocalDensity.current
            val pixelPerUnit=with(density) {unit.toPx()}
            val currentSession by rememberUpdatedState(s)
            val currentAction by rememberUpdatedState(action)
            val currentSelect by rememberUpdatedState(select)
            val returnX by animateFloatAsState(if(dragging)delta.x else 0f,spring(dampingRatio=.62f,stiffness=Spring.StiffnessMedium),label="snapX")
            val returnY by animateFloatAsState(if(dragging)delta.y else 0f,spring(dampingRatio=.62f,stiffness=Spring.StiffnessMedium),label="snapY")
            val label=stringResource(R.string.piece_access,stringResource(ShapeNames[p.shape.ordinal]),stringResource(ColorNames[p.color]),number(i+1))
            Box(Modifier.offset(unit*(pos.x-tileSize/2+if(dragging)delta.x else returnX),unit*(pos.y-tileSize/2+if(dragging)delta.y else returnY)).size(unit*tileSize)
                .zIndex(if(dragging)10f else 1f).scale(if(dragging)1.16f else 1f)
                .clip(RoundedCornerShape(24.dp)).background(if(selected==i)Color(0xFFFFF3AF) else Color.White)
                .border(if(selected==i || hint is Action.Place && hint.piece==i || hint is Action.Rotate && hint.piece==i)2.dp else 1.dp,if(selected==i || hint is Action.Place && hint.piece==i || hint is Action.Rotate && hint.piece==i)Gold else Color(0xFF9C67E8),RoundedCornerShape(24.dp))
                .pointerInput(s.levelId,i,pixelPerUnit) {
                    detectDragGestures(onDragStart={dragging=true;delta=Offset.Zero;currentSelect(i)},onDragCancel={dragging=false},onDragEnd={
                        val end=pos+delta
                        val t=targets.indices.minByOrNull { (targetPosition(l,it)-end).getDistance() }
                        if(t!=null && (targetPosition(l,t)-end).getDistance()<targetSize*1.08f)currentAction(Action.Place(i,t))
                        dragging=false
                    },onDrag={change,amount -> change.consume();delta+=amount/pixelPerUnit})
                }.clickable {
                    select(i)
                    if(l.mode != Mode.SHADOWS || l.difficulty==0) {
                        targets.indices.firstOrNull { j -> Engine.reduce(s,Action.Place(i,j)).placed.size>s.placed.size }
                            ?.let { target -> action(Action.Place(i,target)) }
                    }
                }.testTag("piece_$i").semantics {contentDescription=label},contentAlignment=Alignment.Center) {
                ShapeArt(p.copy(turn=s.rotations[i] ?: p.turn),Modifier.fillMaxSize(),glow=selected==i)
            }
        }
    }
}
@Composable
private fun MemoryBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val cols=if(l.pieces.size<=8)3 else 4;val rows=(l.pieces.size+cols-1)/cols
    val gap=if(cols==3)265f else 223f
    val tile=if(cols==3)224f else 194f
    l.pieces.forEachIndexed { i,p ->
        val x=500f+(i%cols-(cols-1)/2f)*gap;val y=500f+(i/cols-(rows-1)/2f)*(if(rows==4)222f else 260f)
        val revealed=i in s.flipped || i in s.matched
        val rotation by animateFloatAsState(if(revealed)0f else 180f,tween(250),label="flip")
        val desc=stringResource(R.string.card_access,number(i+1))
        Box(Modifier.offset(unit*(x-tile/2),unit*(y-tile/2)).size(unit*tile).graphicsLayer {rotationY=rotation;cameraDistance=12*density}
            .clip(RoundedCornerShape(20.dp)).background(if(revealed)Color.White else Purple)
            .border(if(hint is Action.Flip && hint.card==i)3.dp else 1.dp,if(hint is Action.Flip && hint.card==i)Gold else Purple.copy(alpha=.20f),RoundedCornerShape(20.dp))
            .alpha(if(i in s.matched).6f else 1f).clickable(enabled=i !in s.matched) {action(Action.Flip(i))}.testTag("card_$i").semantics {contentDescription=desc},contentAlignment=Alignment.Center) {
            if(rotation<90f) ShapeArt(p,Modifier.fillMaxSize().padding(10.dp))
            else Box(Modifier.graphicsLayer {rotationY=180f}) {ShapeArt(Piece(Shape.DIAMOND,2),Modifier.size(unit*95f));SymbolArt(Symbol.STAR,Modifier.size(unit*46f).align(Alignment.Center))}
        }
    }
}
@Composable
private fun MazeBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val m=l.maze!!;val cell=850f/m.width;val margin=75f
    val currentAction by rememberUpdatedState(action)
    val density=LocalDensity.current;val unitPx=with(density) {unit.toPx()}
    val current by rememberUpdatedState(s)
    fun toCell(pos:Offset):Cell=Cell(((pos.x/unitPx-margin)/cell).toInt(),((pos.y/unitPx-margin)/cell).toInt())
    Box(Modifier.fillMaxSize().pointerInput(l.id,unitPx) {detectDragGestures(onDragStart={p ->val c=toCell(p);if(c!=current.position)currentAction(Action.Move(c))},onDrag={change,_ ->change.consume();val c=toCell(change.position);if(c!=current.position)currentAction(Action.Move(c))})}) {
        Canvas(Modifier.fillMaxSize()) {
            val sc=size.width/1000f
            repeat(m.width) {x ->repeat(m.height) {y ->
                val c=Cell(x,y);val top=Offset((margin+x*cell)*sc,(margin+y*cell)*sc)
                drawRoundRect(if(c in m.open) Color.White else Ink.copy(alpha=.8f),top+Offset(2f,2f),Size(cell*sc-4,cell*sc-4),CornerRadius(9f))
                if(c in s.trail)drawCircle(Mint.copy(alpha=.24f),cell*sc*.18f,top+Offset(cell*sc/2,cell*sc/2))
            }}
        }
        m.open.forEach {c ->
            val pos=Offset(margin+(c.x+.5f)*cell,margin+(c.y+.5f)*cell)
            val desc=stringResource(R.string.maze_access,number(c.x+1),number(c.y+1))
            Box(Modifier.offset(unit*(pos.x-cell/2),unit*(pos.y-cell/2)).size(unit*cell).clickable {action(Action.Move(c))}.testTag("cell_${c.x}_${c.y}").semantics {contentDescription=desc},contentAlignment=Alignment.Center) {
                if(c==m.end) Canvas(Modifier.fillMaxSize()) {drawCircle(Mint.copy(alpha=.25f),size.width*.4f,center);drawCircle(Mint,size.width*.32f,center,style=Stroke(size.width*.07f));drawCircle(Paper.copy(alpha=.6f),size.width*.17f,center,style=Stroke(size.width*.025f))}
                if(c==m.key && !s.hasKey) Canvas(Modifier.fillMaxSize()) {drawCircle(Gold,size.width*.17f,Offset(size.width*.37f,size.height*.4f),style=Stroke(size.width*.06f));drawLine(Gold,Offset(size.width*.5f,size.height*.52f),Offset(size.width*.73f,size.height*.75f),size.width*.08f);drawLine(Gold,Offset(size.width*.63f,size.height*.65f),Offset(size.width*.77f,size.height*.55f),size.width*.06f)}
                if(c==m.door && !s.hasKey) SymbolArt(Symbol.LOCK,Modifier.fillMaxSize().padding(3.dp),Coral)
                if(hint is Action.Move && hint.cell==c) Canvas(Modifier.fillMaxSize()) {drawRoundRect(Gold,cornerRadius=CornerRadius(8f),style=Stroke(4f))}
                if(c==s.position) ShapeArt(l.pieces[0],Modifier.fillMaxSize(),glow=true)
            }
        }
    }
}
@Composable
private fun PatternBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val sequence=l.pattern+l.targets.take(s.round)
    val cols=4
    sequence.forEachIndexed { i,p ->ShapeArt(p,Modifier.offset(unit*(110f+(i%cols)*205f),unit*(95f+(i/cols)*180f)).size(unit*165f))}
    val idx=sequence.size
    Box(Modifier.offset(unit*(110f+(idx%cols)*205f),unit*(95f+(idx/cols)*180f)).size(unit*165f).border(2.dp,Gold,RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center) {Text("?",color=Gold,fontSize=34.sp,fontWeight=FontWeight.Black)}
    l.pieces.forEachIndexed { i,p ->OptionTile(p,i,Offset(170f+i*220f,800f),hint,action,unit,180f)}
}
@Composable
private fun OptionTile(p:Piece,index:Int,pos:Offset,hint:Action?,action:(Action)->Unit,unit:Dp,tile:Float=210f,content:(@Composable ()->Unit)?=null) {
    val desc=stringResource(R.string.piece_access,stringResource(ShapeNames[p.shape.ordinal]),stringResource(ColorNames[p.color]),number(index+1))
    Box(Modifier.offset(unit*(pos.x-tile/2),unit*(pos.y-tile/2)).size(unit*tile).shadow(4.dp,RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color.White,Color(0xFFFFEFBA)))).border(if(hint is Action.Choose && hint.option==index)3.dp else 1.dp,if(hint is Action.Choose && hint.option==index)Gold else Color(0xFF9971DF),RoundedCornerShape(22.dp)).clickable {action(Action.Choose(index))}.testTag("option_$index").semantics {contentDescription=desc},contentAlignment=Alignment.Center) {
        if(content!=null)content() else ShapeArt(p,Modifier.fillMaxSize().padding(5.dp))
    }
}
@Composable
private fun LogicBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val round=s.round.coerceAtMost(l.answers.lastIndex)
    val pieces=l.pieces.drop(round*3).take(3)
    when(l.rule) {
        0,1 -> { // Three candidates form the whole odd-one-out puzzle.
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,470f),hint,action,unit,240f)}
        }
        2 -> {
            val correct=l.answers[round];val count=correct+1
            repeat(count) {i ->ShapeArt(l.pattern[round],Modifier.offset(unit*(420f+i*110f-(count-1)*55f),unit*185f).size(unit*160f))}
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,715f),hint,action,unit,250f) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {repeat(i+1) {ShapeArt(p,Modifier.size(unit*65f))}}
            }}
        }
        3 -> {
            ShapeArt(l.pattern[round],Modifier.offset(unit*370f,unit*140f).size(unit*260f),glow=true)
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,720f),hint,action,unit,240f)}
        }
        4 -> {
            val a=l.pattern[round*2];val b=l.pattern[round*2+1]
            ShapeArt(a,Modifier.offset(unit*170f,unit*140f).size(unit*230f))
            ShapeArt(b,Modifier.offset(unit*610f,unit*140f).size(unit*230f))
            Canvas(Modifier.fillMaxSize()) {drawLine(Gold,Offset(size.width*.45f,size.height*.255f),Offset(size.width*.55f,size.height*.255f),5f);drawLine(Gold,Offset(size.width*.5f,size.height*.205f),Offset(size.width*.5f,size.height*.305f),5f)}
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,720f),hint,action,unit,240f)}
        }
    }
    Row(Modifier.offset(unit*370f,unit*925f).width(unit*260f),horizontalArrangement=Arrangement.SpaceEvenly) {repeat(l.rounds) {i ->Canvas(Modifier.size(8.dp)) {drawCircle(if(i<s.round)Mint else Paper.copy(alpha=.2f))}}}
}

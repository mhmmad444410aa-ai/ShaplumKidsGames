package com.mhmmad.shaplumkidsgames.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.*
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.mhmmad.shaplumkidsgames.*
import com.mhmmad.shaplumkidsgames.R
import com.mhmmad.shaplumkidsgames.engine.*
import com.mhmmad.shaplumkidsgames.engine.Shape
import kotlinx.coroutines.delay
import kotlin.math.*

@Composable
fun Gameplay(state:UiState,vm:GameViewModel,sound:(Boolean)->Unit) {
    val session=state.saved.session ?:return
    val l=Levels.get(session.levelId)
    var selected by remember(session.levelId){mutableIntStateOf(-1)}
    var hint by remember(session.levelId){mutableStateOf<Action?>(null)}
    var feedback by remember(session.levelId){mutableStateOf(false)}
    LaunchedEffect(session.mistakes) { if(session.mistakes>0) {feedback=true;delay(850);feedback=false} }
    LaunchedEffect(session.flipped,state.paused) {if(session.flipped.size==2 && !state.paused){delay(950);vm.action(Action.HidePair)}}
    val currentAction by rememberUpdatedState<(Action)->Unit>{ a->
        vm.action(a)
        if(a !is Action.Hint && a !is Action.HidePair) sound(false)
        hint=null
    }
    val instruction=when(l.mode) {
        Mode.SHAPES->R.string.shape_help;Mode.COLORS->if(l.rule==1)R.string.color_shape_help else R.string.color_help
        Mode.PATTERNS->R.string.pattern_help;Mode.SHADOWS->R.string.shadow_help
        Mode.MAZE->if(l.maze?.key!=null)R.string.maze_key_help else R.string.maze_help
        Mode.ARCHITECT->R.string.architect_help;Mode.MEMORY->R.string.memory_help
        Mode.LOGIC->listOf(R.string.logic_odd_shape,R.string.logic_odd_color,R.string.logic_count,R.string.logic_both,R.string.logic_mix)[l.rule]
    }
    Box(Modifier.fillMaxSize()) {
        PlayroomBackdrop(Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().testTag("gameplay")) {
            Row(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically,
                horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                IconControl(Symbol.HOME,stringResource(R.string.home),{vm.pause(true)},"back")
                Column(Modifier.weight(1f)) {
                    Text(stringResource(ModeNames[l.mode.ordinal]),fontWeight=FontWeight.Black,fontSize=21.sp,color=Color(0xFF173F82),maxLines=1)
                    Text(stringResource(R.string.level,number(l.number)),fontWeight=FontWeight.Bold,fontSize=14.sp,color=Color(0xFF2950A0))
                }
                IconControl(Symbol.PAUSE,stringResource(R.string.pause),{vm.pause(true)},"pause")
            }
            Column(Modifier.fillMaxWidth().padding(horizontal=12.dp)
                .shadow(6.dp,RoundedCornerShape(22.dp)).clip(RoundedCornerShape(22.dp))
                .background(Color(0xFFF9FFFF)).border(2.dp,Color(0xFF7CCBFF),RoundedCornerShape(22.dp))
                .padding(horizontal=14.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    Text(stringResource(instruction),modifier=Modifier.weight(1f),textAlign=TextAlign.Center,
                        fontSize=17.sp,lineHeight=21.sp,fontWeight=FontWeight.Black,color=Color(0xFF173F82),maxLines=2)
                }
                LinearProgressIndicator(progress={Engine.progress(session)},modifier=Modifier.fillMaxWidth()
                    .height(11.dp).clip(RoundedCornerShape(18.dp)),color=Color(0xFF39CC89),trackColor=Color(0xFFE3D8FF),drawStopIndicator={})
                if(l.difficulty==0 && l.mode in listOf(Mode.SHAPES,Mode.COLORS,Mode.SHADOWS,Mode.ARCHITECT))
                    Text(stringResource(R.string.v13_touch_or_drag),Modifier.fillMaxWidth(),textAlign=TextAlign.Center,
                        fontSize=13.sp,color=Color(0xFF445DA8),fontWeight=FontWeight.Bold)
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal=6.dp,vertical=5.dp),contentAlignment=Alignment.Center) {
                Board(l,session,selected,{selected=it},hint,currentAction)
            }
            Row(Modifier.fillMaxWidth().padding(start=14.dp,end=14.dp,top=4.dp,bottom=10.dp),
                horizontalArrangement=Arrangement.spacedBy(9.dp),verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    ActionButton(stringResource(R.string.hint),{
                        val h=Engine.hint(session);hint=h
                        if(h is Action.Place)selected=h.piece
                        if(h is Action.Rotate)selected=h.piece
                        vm.action(Action.Hint)
                    },Modifier.fillMaxWidth(),Symbol.HINT,Color(0xFF7951D6),"hint")
                }
                if(l.mode==Mode.SHADOWS && l.difficulty>0) {
                    IconControl(Symbol.ROTATE,stringResource(R.string.rotate),{
                        val piece=if(selected>=0 && selected !in session.placed)selected
                          else l.pieces.indices.firstOrNull{it !in session.placed}?:0
                        selected=piece;currentAction(Action.Rotate(piece))
                    },"rotate")
                }
            }
            if(feedback||hint!=null) Text(if(feedback)stringResource(R.string.v13_try_again) else stringResource(R.string.hint_message),
                modifier=Modifier.fillMaxWidth().padding(bottom=3.dp),color=Color(0xFF4A2988),
                fontSize=13.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
        }
    }
    if(state.paused) AlertDialog(onDismissRequest={vm.pause(false)},
        title={Text(stringResource(R.string.paused))},
        text={Text(stringResource(R.string.v13_play_at_your_pace))},
        confirmButton={TextButton(onClick={vm.pause(false)},Modifier.testTag("unpause")){Text(stringResource(R.string.keep_playing))}},
        dismissButton={Column {
            TextButton(onClick={vm.pause(false);vm.start(session.levelId)},Modifier.testTag("restart")){Text(stringResource(R.string.replay))}
            TextButton(onClick={vm.navigate(Page.WORLD)},Modifier.testTag("pause_home")){Text(stringResource(R.string.home))}
        }})
}

@Composable
private fun Board(l:Level,s:Session,selected:Int,select:(Int)->Unit,hint:Action?,action:(Action)->Unit) {
    BoxWithConstraints(Modifier.fillMaxSize(),contentAlignment=Alignment.Center) {
        val placement=l.mode in listOf(Mode.SHAPES,Mode.COLORS,Mode.SHADOWS,Mode.ARCHITECT)
        val ratio=if(placement)1.24f else 1f
        val width=minOf(maxWidth,maxHeight/ratio)
        val height=width*ratio
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(Modifier.width(width).height(height)
                .shadow(14.dp,RoundedCornerShape(35.dp))
                .clip(RoundedCornerShape(35.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFFFFDF1),Color(0xFFFFE8B6),Color(0xFFFFCBDA))))
                .border(5.dp,Color(0xFF42BDE5),RoundedCornerShape(35.dp)).testTag("board")) {
                val unit=width/1000f
                Canvas(Modifier.fillMaxSize()) {
                    val u=size.width/1000f
                    val yFactor=if(placement)size.height/1240f else size.height/1000f
                    if(placement) {
                        drawRoundRect(Color(0xFF4EBAE8),Offset(29*u,45*yFactor),Size(942*u,680*yFactor),CornerRadius(52*u))
                        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFF8FFFF),Color(0xFFDEF9FB))),
                            Offset(39*u,49*yFactor),Size(922*u,640*yFactor),CornerRadius(44*u))
                        drawRoundRect(Color(0xFFD68555),Offset(30*u,755*yFactor),Size(940*u,446*yFactor),CornerRadius(49*u))
                        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFFFF1CC),Color(0xFFFFDB91))),
                            Offset(40*u,747*yFactor),Size(920*u,420*yFactor),CornerRadius(43*u))
                        drawLine(Color(0xFFAD6A3E).copy(alpha=.18f),Offset(90*u,1190*yFactor),Offset(910*u,1190*yFactor),3*u)
                        repeat(8){i->
                            val p=Offset((130+i*103)*u,714*yFactor)
                            drawCircle(listOf(Color(0xFFFEC64A),Color(0xFFFF76A0),Color(0xFF5DD3D4))[i%3].copy(alpha=.9f),7*u,p)
                        }
                    } else {
                        drawRoundRect(Color.White.copy(alpha=.45f),Offset(50*u,65*yFactor),Size(900*u,862*yFactor),CornerRadius(48*u))
                        repeat(20){i->
                            val x=((i*79+21)%90+5)*u*10
                            val y=((i*43+9)%86+7)*yFactor*10
                            drawCircle(listOf(Color(0xFFFFD46E),Color(0xFF94DEF8),Color(0xFFF1A1D7))[i%3].copy(alpha=.16f),15*u,Offset(x,y))
                        }
                    }
                }
                when(l.mode) {
                    Mode.SHAPES,Mode.COLORS,Mode.SHADOWS,Mode.ARCHITECT -> PlacementBoard(l,s,selected,select,hint,action,unit)
                    Mode.MEMORY -> MemoryBoard(l,s,hint,action,unit)
                    Mode.MAZE -> MazeBoard(l,s,hint,action,unit)
                    Mode.PATTERNS -> PatternBoard(l,s,hint,action,unit)
                    Mode.LOGIC -> LogicBoard(l,s,hint,action,unit)
                }
            }
        }
    }
}

private fun sourcePosition(i:Int,count:Int):Offset {
    val cols=when{ count<=3->count;count<=6->3;else->4 }
    val rows=(count+cols-1)/cols
    val row=i/cols
    val actualCols=minOf(cols,count-row*cols)
    val gap=if(cols==4)221f else 260f
    val y=when(rows){1->932f;2->856f+row*214f;else->815f+row*147f}
    return Offset(500f+(i%cols-(actualCols-1)/2f)*gap,y)
}

private fun targetPosition(l:Level,i:Int):Offset {
    if(l.mode==Mode.ARCHITECT) {
        val bp=l.blueprint[i]
        val minY=l.blueprint.minOf{it.y}
        val maxY=l.blueprint.maxOf{it.y}
        val step=minOf(117f,525f/(maxY-minY).coerceAtLeast(1))
        return Offset(105f+bp.x*193f,110f+(bp.y-minY)*step)
    }
    val count=l.targets.size
    val cols=if(count<=4)count else if(count<=6)3 else 4
    val row=i/cols;val actualCols=minOf(cols,count-row*cols)
    val gap=if(cols>=4)222f else 260f
    return Offset(500f+(i%cols-(actualCols-1)/2f)*gap,if(count<=4)343f else 210f+row*224f)
}

@Composable
private fun PlacementBoard(l:Level,s:Session,selected:Int,select:(Int)->Unit,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val targets=if(l.mode==Mode.ARCHITECT)l.blueprint.map{it.piece} else l.targets
    val targetSize=when {targets.size<=3->245f;targets.size<=5->215f;else->184f}
    val pieceSize=when{l.pieces.size<=4->235f;l.pieces.size<=7->188f;else->145f}
    targets.forEachIndexed {i,p->
        val pos=targetPosition(l,i)
        val count=s.placed.values.count{it==i}
        val filled=count>0
        val usable=l.mode!=Mode.ARCHITECT||l.blueprint[i].support<0||l.blueprint[i].support in s.placed.values
        val glow=hint is Action.Place && hint.target==i
        val targetScale by animateFloatAsState(if(filled)1f else .94f,
            spring(dampingRatio=.47f,stiffness=Spring.StiffnessMediumLow),label="targetPop")
        val label=stringResource(R.string.target_access,number(i+1))
        val border=if(glow)Color(0xFFFFB220) else if(!usable)Color(0xFFB5B2B8) else Color(0xFF3FC9DE)
        Box(Modifier.offset(unit*(pos.x-targetSize/2f),unit*(pos.y-targetSize/2f))
            .size(unit*targetSize).scale(targetScale)
            .shadow(if(glow)11.dp else 5.dp,RoundedCornerShape(30.dp))
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color.White,if(filled)Color(0xFFFFF1B0) else Color(0xFFDAF6FB))))
            .border(if(glow)5.dp else 3.dp,border,RoundedCornerShape(30.dp))
            .clickable {if(selected>=0)action(Action.Place(selected,i))}
            .testTag("target_$i").semantics {contentDescription=label},contentAlignment=Alignment.Center) {
            if(l.mode==Mode.COLORS) {
                ShapeArt(p,Modifier.fillMaxSize().padding(if(filled)18.dp else 13.dp),faded=!filled,glow=glow)
                Canvas(Modifier.fillMaxSize()) {
                    drawRoundRect(Palette[p.color],Offset(size.width*.16f,size.height*.77f),
                        Size(size.width*.68f,size.height*.10f),CornerRadius(11f))
                    repeat(count.coerceAtMost(5)) {k->
                        drawCircle(Color(0xFFFFD344),size.width*.05f,
                            Offset(size.width*(.20f+k*.14f),size.height*.91f))
                    }
                }
            } else {
                ShapeArt(p,Modifier.fillMaxSize().padding(8.dp),
                    silhouette=l.mode==Mode.SHADOWS&&!filled,
                    faded=!filled && l.mode!=Mode.SHADOWS,
                    glow=glow)
            }
            if(filled && l.mode!=Mode.COLORS) {
                SymbolArt(Symbol.STAR,Modifier.align(Alignment.TopEnd).padding(4.dp).size(21.dp),Color(0xFFFFCA45))
            }
        }
    }
    l.pieces.forEachIndexed {i,p->
        if(i !in s.placed) {
            val pos=sourcePosition(i,l.pieces.size)
            var dragging by remember(s.levelId,i){mutableStateOf(false)}
            var delta by remember(s.levelId,i){mutableStateOf(Offset.Zero)}
            val density=LocalDensity.current
            val pixelPerUnit=with(density){unit.toPx()}
            val currentSession by rememberUpdatedState(s)
            val currentAction by rememberUpdatedState(action)
            val currentSelect by rememberUpdatedState(select)
            val px by animateFloatAsState(if(dragging)delta.x else 0f,spring(stiffness=Spring.StiffnessLow),label="returnX")
            val py by animateFloatAsState(if(dragging)delta.y else 0f,spring(stiffness=Spring.StiffnessLow),label="returnY")
            val raised by animateFloatAsState(if(dragging)1.15f else 1f,spring(dampingRatio=.5f),label="toyLift")
            val label=stringResource(R.string.piece_access,stringResource(ShapeNames[p.shape.ordinal]),stringResource(ColorNames[p.color]),number(i+1))
            Box(Modifier.offset(unit*(pos.x-pieceSize/2+px),unit*(pos.y-pieceSize/2+py))
                .size(unit*pieceSize).zIndex(if(dragging)100f else 1f).scale(raised)
                .shadow(if(dragging)17.dp else 8.dp,RoundedCornerShape(27.dp))
                .clip(RoundedCornerShape(27.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF),if(selected==i)Color(0xFFFFE991) else Color(0xFFFFF2DC))))
                .border(if(selected==i||dragging)4.dp else 2.dp,
                    if(selected==i||dragging)Color(0xFFFFBB2E) else Color(0xFF63C7EB),RoundedCornerShape(27.dp))
                .pointerInput(s.levelId,i,pixelPerUnit) {
                    detectDragGestures(
                        onDragStart={dragging=true;delta=Offset.Zero;currentSelect(i)},
                        onDragCancel={dragging=false},
                        onDragEnd={
                            val end=pos+delta
                            // Magnetic assistance: accept nearby compatible sockets, avoiding precision-drag frustration.
                            val validTargets=targets.indices.filter {j->
                                Engine.reduce(currentSession,Action.Place(i,j)).placed.size>currentSession.placed.size
                            }
                            val closest=validTargets.minByOrNull{j->(targetPosition(l,j)-end).getDistance()}
                            val magnetRadius=(targetSize+pieceSize)*.64f
                            if(closest!=null && (targetPosition(l,closest)-end).getDistance()<=magnetRadius)
                                currentAction(Action.Place(i,closest))
                            dragging=false
                        },
                        onDrag={change,amount->change.consume();delta+=amount/pixelPerUnit}
                    )
                }
                .clickable {
                    currentSelect(i)
                    if(l.difficulty==0) {
                        targets.indices.firstOrNull{j->Engine.reduce(s,Action.Place(i,j)).placed.size>s.placed.size}
                            ?.let{currentAction(Action.Place(i,it))}
                    }
                }.testTag("piece_$i").semantics {contentDescription=label},contentAlignment=Alignment.Center) {
                ShapeArt(p.copy(turn=s.rotations[i]?:p.turn),Modifier.fillMaxSize().padding(6.dp),glow=selected==i)
                if(dragging) SymbolArt(Symbol.STAR,Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp),Color(0xFFFFD75A))
            }
        }
    }
}
@Composable
private fun MemoryBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val cols=if(l.pieces.size<=8)3 else 4;val rows=(l.pieces.size+cols-1)/cols
    val gap=if(cols==3)265f else 223f
    val tile=if(cols==3)224f else 194f
    l.pieces.forEachIndexed { i,p ->
        val x=500f+(i%cols-(cols-1)/2f)*gap;val y=500f+(i/cols-(rows-1)/2f)*(if(rows==4)222f else 260f)
        val revealed=i in s.flipped || i in s.matched
        val rotation by animateFloatAsState(if(revealed)0f else 180f,tween(250),label="flip")
        val desc=stringResource(R.string.card_access,number(i+1))
        Box(Modifier.offset(unit*(x-tile/2),unit*(y-tile/2)).size(unit*tile).graphicsLayer {rotationY=rotation;cameraDistance=12*density}
            .clip(RoundedCornerShape(20.dp)).background(if(revealed)Color.White else Color(0xFF4C76D7))
            .border(if(hint is Action.Flip && hint.card==i)3.dp else 1.dp,if(hint is Action.Flip && hint.card==i)Gold else Purple.copy(alpha=.20f),RoundedCornerShape(20.dp))
            .alpha(if(i in s.matched).6f else 1f).clickable(enabled=i !in s.matched) {action(Action.Flip(i))}.testTag("card_$i").semantics {contentDescription=desc},contentAlignment=Alignment.Center) {
            if(rotation<90f) ShapeArt(p,Modifier.fillMaxSize().padding(10.dp))
            else Box(Modifier.graphicsLayer {rotationY=180f}) {ShapeArt(Piece(Shape.DIAMOND,2),Modifier.size(unit*95f));SymbolArt(Symbol.STAR,Modifier.size(unit*46f).align(Alignment.Center))}
        }
    }
}
@Composable
private fun MazeBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val m=l.maze!!;val cell=850f/m.width;val margin=75f
    val currentAction by rememberUpdatedState(action)
    val density=LocalDensity.current;val unitPx=with(density) {unit.toPx()}
    val current by rememberUpdatedState(s)
    fun toCell(pos:Offset):Cell=Cell(((pos.x/unitPx-margin)/cell).toInt(),((pos.y/unitPx-margin)/cell).toInt())
    Box(Modifier.fillMaxSize().pointerInput(l.id,unitPx) {detectDragGestures(onDragStart={p ->val c=toCell(p);if(c!=current.position)currentAction(Action.Move(c))},onDrag={change,_ ->change.consume();val c=toCell(change.position);if(c!=current.position)currentAction(Action.Move(c))})}) {
        Canvas(Modifier.fillMaxSize()) {
            val sc=size.width/1000f
            repeat(m.width) {x ->repeat(m.height) {y ->
                val c=Cell(x,y);val top=Offset((margin+x*cell)*sc,(margin+y*cell)*sc)
                drawRoundRect(if(c in m.open) Color(0xFFF7FFF5) else Color(0xFF3974B5),top+Offset(2f,2f),Size(cell*sc-4,cell*sc-4),CornerRadius(9f))
                if(c in s.trail)drawCircle(Mint.copy(alpha=.24f),cell*sc*.18f,top+Offset(cell*sc/2,cell*sc/2))
            }}
        }
        m.open.forEach {c ->
            val pos=Offset(margin+(c.x+.5f)*cell,margin+(c.y+.5f)*cell)
            val desc=stringResource(R.string.maze_access,number(c.x+1),number(c.y+1))
            Box(Modifier.offset(unit*(pos.x-cell/2),unit*(pos.y-cell/2)).size(unit*cell).clickable {action(Action.Move(c))}.testTag("cell_${c.x}_${c.y}").semantics {contentDescription=desc},contentAlignment=Alignment.Center) {
                if(c==m.end) Canvas(Modifier.fillMaxSize()) {drawCircle(Mint.copy(alpha=.25f),size.width*.4f,center);drawCircle(Mint,size.width*.32f,center,style=Stroke(size.width*.07f));drawCircle(Paper.copy(alpha=.6f),size.width*.17f,center,style=Stroke(size.width*.025f))}
                if(c==m.key && !s.hasKey) Canvas(Modifier.fillMaxSize()) {drawCircle(Gold,size.width*.17f,Offset(size.width*.37f,size.height*.4f),style=Stroke(size.width*.06f));drawLine(Gold,Offset(size.width*.5f,size.height*.52f),Offset(size.width*.73f,size.height*.75f),size.width*.08f);drawLine(Gold,Offset(size.width*.63f,size.height*.65f),Offset(size.width*.77f,size.height*.55f),size.width*.06f)}
                if(c==m.door && !s.hasKey) SymbolArt(Symbol.LOCK,Modifier.fillMaxSize().padding(3.dp),Coral)
                if(hint is Action.Move && hint.cell==c) Canvas(Modifier.fillMaxSize()) {drawRoundRect(Gold,cornerRadius=CornerRadius(8f),style=Stroke(4f))}
                if(c==s.position) ShapeArt(l.pieces[0],Modifier.fillMaxSize(),glow=true)
            }
        }
    }
}
@Composable
private fun PatternBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val sequence=l.pattern+l.targets.take(s.round)
    val cols=4
    sequence.forEachIndexed { i,p ->ShapeArt(p,Modifier.offset(unit*(110f+(i%cols)*205f),unit*(95f+(i/cols)*180f)).size(unit*165f))}
    val idx=sequence.size
    Box(Modifier.offset(unit*(110f+(idx%cols)*205f),unit*(95f+(idx/cols)*180f)).size(unit*165f).border(2.dp,Gold,RoundedCornerShape(18.dp)),contentAlignment=Alignment.Center) {Text("?",color=Gold,fontSize=34.sp,fontWeight=FontWeight.Black)}
    l.pieces.forEachIndexed { i,p ->OptionTile(p,i,Offset(170f+i*220f,800f),hint,action,unit,180f)}
}
@Composable
private fun OptionTile(p:Piece,index:Int,pos:Offset,hint:Action?,action:(Action)->Unit,unit:Dp,tile:Float=210f,content:(@Composable ()->Unit)?=null) {
    val desc=stringResource(R.string.piece_access,stringResource(ShapeNames[p.shape.ordinal]),stringResource(ColorNames[p.color]),number(index+1))
    Box(Modifier.offset(unit*(pos.x-tile/2),unit*(pos.y-tile/2)).size(unit*tile).shadow(4.dp,RoundedCornerShape(24.dp)).clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color.White,Color(0xFFFFE3A3)))).border(if(hint is Action.Choose && hint.option==index)3.dp else 1.dp,if(hint is Action.Choose && hint.option==index)Gold else Color(0xFF9971DF),RoundedCornerShape(22.dp)).clickable {action(Action.Choose(index))}.testTag("option_$index").semantics {contentDescription=desc},contentAlignment=Alignment.Center) {
        if(content!=null)content() else ShapeArt(p,Modifier.fillMaxSize().padding(5.dp))
    }
}
@Composable
private fun LogicBoard(l:Level,s:Session,hint:Action?,action:(Action)->Unit,unit:Dp) {
    val round=s.round.coerceAtMost(l.answers.lastIndex)
    val pieces=l.pieces.drop(round*3).take(3)
    when(l.rule) {
        0,1 -> { // Three candidates form the whole odd-one-out puzzle.
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,470f),hint,action,unit,240f)}
        }
        2 -> {
            val correct=l.answers[round];val count=correct+1
            repeat(count) {i ->ShapeArt(l.pattern[round],Modifier.offset(unit*(420f+i*110f-(count-1)*55f),unit*185f).size(unit*160f))}
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,715f),hint,action,unit,250f) {
                Column(horizontalAlignment=Alignment.CenterHorizontally) {repeat(i+1) {ShapeArt(p,Modifier.size(unit*65f))}}
            }}
        }
        3 -> {
            ShapeArt(l.pattern[round],Modifier.offset(unit*370f,unit*140f).size(unit*260f),glow=true)
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,720f),hint,action,unit,240f)}
        }
        4 -> {
            val a=l.pattern[round*2];val b=l.pattern[round*2+1]
            ShapeArt(a,Modifier.offset(unit*170f,unit*140f).size(unit*230f))
            ShapeArt(b,Modifier.offset(unit*610f,unit*140f).size(unit*230f))
            Canvas(Modifier.fillMaxSize()) {drawLine(Gold,Offset(size.width*.45f,size.height*.255f),Offset(size.width*.55f,size.height*.255f),5f);drawLine(Gold,Offset(size.width*.5f,size.height*.205f),Offset(size.width*.5f,size.height*.305f),5f)}
            pieces.forEachIndexed {i,p ->OptionTile(p,i,Offset(200f+i*300f,720f),hint,action,unit,240f)}
        }
    }
    Row(Modifier.offset(unit*370f,unit*925f).width(unit*260f),horizontalArrangement=Arrangement.SpaceEvenly) {repeat(l.rounds) {i ->Canvas(Modifier.size(8.dp)) {drawCircle(if(i<s.round)Mint else Paper.copy(alpha=.2f))}}}
}
